title: unity_实用小技巧（避免游戏对象被销毁时声音消失）
date: '2019-09-11 21:59:49'
updated: '2019-09-11 22:00:10'
tags: [游戏开发, Unity]
permalink: /articles/2019/09/11/1568210389801.html
---
在游戏中我们使用碰撞检测，当两个物体发生碰撞时产生声音音效，代码如下：

![image.png](https://img.hacpai.com/file/2019/09/image-d5a7c51c.png)


如果使用上述代码，我们会发现，在脚本中使用AudioSource声明该声音，当该物体被销毁时声音也会立刻停止。

 

但是我们希望声音继续播放完，那么此时我们应该使用AudioClip声明，代码如下：
![image.png](https://img.hacpai.com/file/2019/09/image-abc200b9.png)


```
public AudioSource music_pickup;  
  
    void OnTriggleEnter(Collider other)  
    {  
        Player player = other.GetComponent<Player>();  
        player.hasKey = true;  
        music_pickup.Play();  
        Destroy(this.gameObject);  
    }
```
