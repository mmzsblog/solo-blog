title: SpringCloud（八）：sidecar异构微服务
date: '2019-08-06 15:54:33'
updated: '2019-08-06 15:54:33'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565078073512.html
---

# 0、理解
通过sidecar将异构平台的微服务注册到Eureka；让其和SpringCloud的生态空间连在一起；
# 1、使用
pom.xml`
```
<dependency>
<groupId>org.springframework.cloud</groupId>
<artifactId>spring-cloud-netflix-sidecar</artifactId>
</dependency>
```
application.yml
```
spring:
  application:
    name: microservice-sidecar
server:
  port: 8070
eureka: 
  client: 
    service-url:
      defaultZone: http://localhost:8761/eureka
  instance:
    prefer-ip-address: true
sidecar:
  port: 8060
  health-uri: http://localhost:8060/health.json
   
```
启动类SidecarApplication.java
```
@SpringBootApplication
//注册Sidecar；@EnableSidecar是一个组合注解
@EnableSidecar
public class SidecarApplication {
public static void main(String[] args) {
System.out.println("Hello Zuul!");
SpringApplication.run(SidecarApplication.class, args);
}
}
```
### 注意
- 1、
当异构微服务和eureka不运行在同一个hostname上时，我们需要配置
`${eureka.instance.hostName}`
- 2、每一个异构微服务节点就需要一个sidecar，当需要异构的微服务很多时，就很麻烦了；且sidecar本身对业务没什么作用，仅仅做一个‘汇总’。
