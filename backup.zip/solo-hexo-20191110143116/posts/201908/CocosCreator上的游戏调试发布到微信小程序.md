title: CocosCreator上的游戏（调试）发布到微信小程序
date: '2019-08-09 22:49:27'
updated: '2019-08-09 22:54:53'
tags: [CocosCreator, 游戏开发]
permalink: /articles/2019/08/09/1565362167324.html
---
![](https://img.hacpai.com/bing/20180827.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# CocosCreator上的游戏（调试）发布到微信小程序
## 1.下载CocosCreator，微信开发者工具
官网地址：http://www.cocos.com/download
![1.png](https://img.hacpai.com/file/2019/08/1-993f0b8e.png)

官网下载：https://developers.weixin.qq.com/minigame/dev/devtools/download.html

## 2.安装
和普通的软件安装一样，这里博主就不多说了。

## 3.打开CocosCreator
你可以打开一个项目，或者新建一个项目。

## 4.选择“偏好设置”
![4.png](https://img.hacpai.com/file/2019/08/4-5f916a91.png)

## 5.修改“原生开发工具环境”的属性
将下面选中的修改为微信开发工具的安装路径，比如博主的是：F:\个人\WeiGame\install\微信web开发者工具
![5.png](https://img.hacpai.com/file/2019/08/5-5fc39adb.png)

保存并关闭。

## 6.打开“构建发布”
![6.png](https://img.hacpai.com/file/2019/08/6-ca66316d.png)

## 7.按照下面步骤执行
其中3步如果你有appid就填自己的，没有就填图中的，图中的appid为游客id。
![7.png](https://img.hacpai.com/file/2019/08/7-12f1050f.png)

点击运行没错，会自动打开微信开发工具，如图显示
![8.png](https://img.hacpai.com/file/2019/08/8-c90e828a.png)


## 8.点击编译，预览
会出现二维码，你只需要用你注册该小程序的微信扫一扫，即可开始测试体验。注意：必须是注册该小程序的微信才有权限。
