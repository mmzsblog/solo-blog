title: unity基础
date: '2019-08-21 18:09:37'
updated: '2019-08-21 18:11:33'
tags: [游戏开发, Unity]
permalink: /articles/2019/08/21/1566382177030.html
---
><font color="#800080" size="6px" face="宋体">**推荐阅读：**</font>
>- <font size="4px" face="楷体"> [QQ群：704621321](http://qm.qq.com/cgi-bin/qm/qr?k=HLQSQCMupMEvLxd7S061X-zpBi8Oo7pM)</font>
>- <font size="4px" face="楷体"> [Unity系列](https://www.mmzsblog.cn/tags/Unity)</font>
      
## Transform 类
Transform.Translate 移动：
例1：
```js
transform.Translate(Vector3.forward * moveSpeed);
```
例2：
```js
transform.Translate(Vector3.up * moveSpeed, Space.World);
```
例3：

```js
transform.Translate(0, 0, moveSpeed);
```
例4：

```js
 transform.Translate(Vector3.right * moveSpeed, Camera.main.transform);
```
Transform.Rotate 绕着通过物体中心点的某个轴旋转：
例1：
```js
transform.Rotate(Vector3.right * rotSpeed);
```
例2：

```js
 transform.Rotate(Vector3.up * rotSpeed, Space.World);
```
例3：

```js
transform.Rotate(rotSpeed, 0, 0);
```
Transform.RotateAround 绕着任意轴旋转

## Transform 与 transform 区别
**就是类（Transform）与对象（transform）的区别**
Transform 组件 ：每个游戏物体默认带有的组件，有且只有一个，不能手动添加。
transform ：当前游戏物体的 Transform 组件对象。
## Time
Time.deltaTime 增量时间，以**秒**计算，完成一帧的时间（只读。 当你乘以Time.deltaTime实际表示：每秒移动物体10米，而不是每帧10米。
注意：在OnGUI里不应该依赖于Time.deltaTime，因为OnGUI可以在每帧被多次调用并且每次调用deltaTime将持有相同的值，直到下一帧再次更新。
## Input
键盘：
GetKey	：当用户按下由name名称确定的按键时，返回 true。
GetKeyDown	：当用户按下指定名称的按键时的那一帧返回 true。
GetKeyUp	：在用户释放给定名字的按键的那一帧返回 true。
鼠标：
GetMouseButton	：当指定的鼠标按钮被按下时返回 true。
GetMouseButtonDown	：在用户按下指定鼠标按键的那一帧返回 true。
GetMouseButtonUp	：在用户释放指定鼠标按键的那一帧返回 true。
**数字键 0 表示鼠标左键；数字键 1 表示鼠标右键；数字键 2 表示鼠标中键。**
GetAxis	根据 axisName 名称返回虚拟输入轴中的值。例如：
```js
float v = Input.GetAxis("Vertical") ;
float h = Input.GetAxis("Horizontal");
```
## Object
Object.Destroy：会在 Update 之后，渲染之前执行销毁操作。
使用方法：

```js
    // 删除当前游戏对象
    Destroy (gameObject);

    // 删除当前这个脚本
    Destroy (this);

    // 删除当前游戏对象上的刚体组件
    Destroy (rigidbody);

    // 5秒后删除这个游戏对象
    Destroy (gameObject, 5);
```
Object.Instance：实例化对象。
使用方法：

```js
    public static Object Instantiate(Object original);
    public static Object Instantiate(Object original, Transform parent);
    public static Object Instantiate(Object original, Transform parent, bool worldPositionStays);
    public static Object Instantiate(Object original, Vector3 position, Quaternion rotation);
    public static Object Instantiate(Object original, Vector3 position, Quaternion rotation, Transform parent);

参数：

original：需要被克隆的原始物体
position：新物体的位置
rotation：新物体的旋转
parent：指定新物体的父物体
worldPositionStays：当指定父物体以后仍保持原始的世界坐标
```
## Resources 资源
Resources类允许你从指定的路径查找或访问资源，但是在Unity中通常不需要使用路径名来访问资源，相反你可以**通过声明一个成员变量来暴露一个资源的引用，然后在检视面板中指定它**。使用这个技巧的时候Unity可以在构建的时候自动计算哪个资源被使用。这从根本上最大限度地减少了实际用于游戏的资源的尺寸。
Resources.Load 加载：路径名使用正斜杠“/”，如果使用反斜杠“\”会不正常运行。
当资源不再需要时，可以使用Resources.UnloadUnusedAssets回收内存。
## Quaternion
四元数表示旋转

优点：
    可以避免万向节锁现象
    只需要一个4维的四元数就可以绕任意过原点的向量的旋转，方便快捷，在某些实现下比旋转矩阵效率更高；
    可以提供平滑插值
缺点：
    比欧拉旋转稍微复杂了一点点，因为多了一个纬度
    理解更困难，不直观
## 灯光和摄像机
**光源类型**

1、 Directional light: 方向光源
类似于自然界的太阳光，该类型光源可以影响场景中的一切游戏对象，与光源所在位置无关，只与光源的角度有关。是最不耗费图形处理器资源的光源类型。

2、Point Light: 点光源
点光源从一个位置发出光线，影响其范围内的所有对象，类似于灯泡的照明效果。点光源的阴影时较耗费图像处理器资源的光源类型。

3、Spltlight: 聚光灯
灯光从一点发出，在一个方向按照一个锥形的范围照射，处于锥形区域内的对象会受到光照照射，类似于射灯的照明效果。聚光灯是较耗费图形处理器资源的灯光类型。

4、Area Light: 区域光／面光源
该类型光源无法应用于实时光照，仅适用于光照贴图烘焙。

**参数介绍**
Cookie: 该项用于为光源指定拥有 alpha 通道的纹理，使光线在不同的地方有不同的亮度。如果光源是聚光灯或方向光，可以指定一个2D 纹理。如果光源是一个点光源，必须指定一个 Cubemap（立方体纹理）。

Cookie Size: 该项用于控制缩放 Cookie 投影。只有方向光有该参数。

**注意：**
Forward 渲染模式下，只有 Directional light 光源可以表现阴影。
Deferred Lighting 渲染模式下， Point light、Spot light 类型光源可以表现阴影（只有发布成 Web 版或单机版才支持）。
## 声音组件
AudioListener： 音频监听组件。该组件用于接收音频，相当于人的耳朵。

**注意：**
为场景添加摄像机时，Unity 会自动为摄像机对象添加 AudioListener 组件，由于一个场景中只能有一个该组件，所以需要手动的删除其他组件，使场景中只保留一个该组件。

unity支持的音频格式： .mp3 .ogg .aiff .wav .mod .it .sm3
## Random 随机数
Range	在最大值（包括）和最小值（包括）范围内返回一个随机数（只读）
## 物理系统
**（一）碰撞检测**
**条件**
 1.两个及以上： 碰撞必须要两个或两个以上的物体相互作用
  2.至少有一个运动的物体：碰撞必须是两个动态或者一个动态一个静态物体发生碰撞
   
   以上说明看出碰撞必须有一个动态物体的存在
    什么是动态物体?会发生运动变化的物体，他必须拥有运动特性->可以受到力的影响
    什么是静态物体?没有运动特性的物体
    如何让物体产生动态特性？ 在Unity引擎中我们可以使用“刚体”实现动态特性
**（二） 刚体**
具有运动特性，在收到外力作用下可以保持物体的形状不发生改变，这样的组件，我们称为“刚体组件”；
**（三）碰撞几何体**
为运动物体和静态物体提供一个几何图形的包围盒来保护我们的物体内部结构，同时提供检测的特性，主要有以下几种：
立方体     球体    胶囊体 网格面 轮距
**（四）Rigidbody 刚体组件**
**物体发生碰撞的必要条件**：两者必须都有碰撞器且至少有一个具有刚体组件。

**unity3d中的碰撞器和触发器的区别？**
       碰撞器是触发器的载体，而触发器只是碰撞器身上的一个属性
       当Is Trigger=false时，碰撞器根据物理引擎引发碰撞，**产生碰撞的效果**，可以调用OnCollisionEnter/Stay/Exit函数；
      当Is Trigger=true时，碰撞器被物理引擎所忽略，**没有碰撞效果**，可以调用OnTriggerEnter/Stay/Exit函数。
       如果既要检测到物体的接触又不想让碰撞检测影响物体移动或要检测一个物件是否经过空间中的某个区域这时就可以用到触发器。
       
对于Unity引擎来说，所有力学的处理都应该放在FixedUpdate进行。

注意：不要更改Time属性中的固定时间，如果更改了可能会造成物理引擎不同步问题
## 协同
Unity引擎不支持C#多线程。
格式：

```js
[修辞]  IEnumerator  协同函数名（行參列表）
```

注意：最多只能有一个参数
例如：

```js
    IEnumerator Run()
    {
        语句;
        yield return new WaitForSeconds(等待时间);// 如果返回以后，下次进入协同方法会从返回的语句之后继续执行，执行完上面的代码后休息指定的秒数，它不会影响引擎更新函数
    }
```
调用协同函数：

```
StartCoroutine(协同函数带实参列表);
```
例如：

```
StartCoroutine("Run");
```
停止协程：

```
StopCoroutine("Run");
```
**异步加载**：使用方法Resources.LoadAsync，结合协程实现异步加载。
例如：

```js
    using UnityEngine;
    using System.Collections;

    public class ExampleClass : MonoBehaviour {
        void Start() {
            StartCoroutine(LoadTexture());
        }
        IEnumerator LoadTexture() {
            ResourceRequest request = Resources.LoadAsync("glass");
            yield return request;
        }
    }
```
**协同**
1、协同必须在 MonoBehaviour 继承类中启动

2、协同定义随便，只要在 Unity 引擎内的什么类中都可以定义

3、协同一旦启动它会立即执行协同函数的第一段，所以你尽量不要把负荷很大的代码写在第一段里

4、协同除了第一次启动会立即执行外，其他时候都是在 Update 函数之后

5、协同是假的多线程，所以它可以无条件访问成员级变量和函数，无需线程互斥

6、协同函数中定义变量是协同函数全局的

7、协同函数中的代码都是过程化的，没有面向对象的概念

8、不要在循环中调用协同方法

9、事件函数也可以改写成协同方法

在协同中可以调用其他协同方法,例如：

```js
StartCoroutine(Run());

yield return StartCoroutine(Run());
```

## 向量的点乘与叉乘
**点乘**
数学表示：a•b = |a| x |b| x cosƟ;
代码表示：

```js
float r = Vector3.Dot(a, b);
```
**意义：**：如果 r 大于 0，则可以判断目标在我的前方；r 小于 0，目标在我后方

a 可以用主角的 forward 方向

b 用目标的 position - 主角的 position

a 的模可以通过 a.magnitude 获得

**差乘**
数学表示：a X b = |a|x|b|xsinƟ;
代码表示：

```js
Vector3 r = Vector3.Cross(a, b);
```
**意义：**：所得的向量与这两个向量垂直的；可以通过所得的向量来判断，目标在我的左方还是右方
## 组件间的消息传递
**作用于当前的游戏物**：

```js
SendMessage ("方法名", object类型的参数，SendMessageOptions.DontRequiredReceiver);
```
**作用于当前游戏物体以及所有的父物体**：

```js
SendMessageUpwards("方法名", object类型的参数, SendMessageOptions.DontRequiredReceiver);
```
**作用于当前游戏物体以及所有的子物体**：

```js
BroadcastMassage ("方法名", object类型的参数, SendMessageOptions.DontRequiredReceiver);
```
提示：
1.调用带参数的方法，不要调用重载方法

2.效率非常低，一般不使用

3.最多只有一个参数
