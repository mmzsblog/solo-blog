title: qq机器人
date: '2019-12-05 13:45:54'
updated: '2019-12-05 13:59:28'
tags: [待分类]
permalink: /articles/2019/12/05/1575524754270.html
---

# 酷q机器人 java版
1.下载酷q机器人 https://dlsec.cqp.me/cqp-xiaoi
2.安装32位jdk1.8
3.下载jcq插件 https://dl.cqp.cc/forum.php?mod=attachment&aid=NDczMDR8MjM0YTI4NTN8MTU3NTUyMzU2M3w4Mzc1MTB8MzczMTg%3D
4.将jcp插件放在酷q机器人app目录下
5.下载java版demo， https://dl.cqp.cc/forum.php?mod=attachment&aid=NDczMTN8NDMxZTkxMjV8MTU3NTUyMzU2M3w4Mzc1MTB8MzczMTg%3D
6.将demo打包，然后将打包后的jar包和json文件放入酷q机器人的以下目录
data\app\com.sobte.cqp.jcq\app
7.启动酷q机器人，进入应用管理，进入jcp，菜单-管理，启动demo。

可能出现问题的地方：
* jdk需要32位，1.8
* json文件编码问题，提供的demo，jcp插件为1.2.7，json文件编码为gbk
* json文件问题，文件名需要与jar包名一致

其他语言开发开参考酷q官网开发社区 https://cqp.cc/t/15124


