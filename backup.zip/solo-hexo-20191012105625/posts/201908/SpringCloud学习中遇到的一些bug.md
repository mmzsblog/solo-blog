title: SpringCloud学习中遇到的一些bug
date: '2019-08-06 15:57:05'
updated: '2019-08-07 14:14:02'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565078225369.html
---
![](https://img.hacpai.com/bing/20181230.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# ======Bug======
## There was a problem with the instance info replicator

- **错误原因：** 
该服务尝试将自己作为客服端注册
- **解决办法：**
在application.yml配置文件中，设置
```
# 注册Eureka服务
eureka:
  client:
    # Eureka服务注册中心会将自己作为客户端来尝试注册它自己，必須禁止
    register-with-eureka: false
    fetch-registry: false
```
## 实体类转化出错： disable SerializationFeature.FAIL_ON_EMPTY_BEANS
- **错误原因：** 
使用的框架是Spring Boot，处理完请求之后，返回数据之前，在POJO转化成JSON时，有些属性违背输出规则或者有些属性循环引用会造成无法输出。
- **解决办法：**
在实体类上面加上注解
```
@JsonIgnoreProperties(value = { "hibernateLazyInitializer", "handler" })
```
## This application has no explicit mapping for /error, so you are seeing this as a fallback.
- **错误原因：** 很可能是你Application启动类放的位置不对。要将Application放在最外层，也就是要包含所有子包。
- **解决办法：** 将Application放在最外层，也就是要包含所有子包。
## message:Request method 'POST' not supported 
There was an unexpected error (type=Internal Server Error, status=500).
status 405 reading UserFeignClient#getUser(User); content: {"timestamp":"2018-09-07T09:01:14.290+0000","status":405,"error":"Method Not Allowed","message":"Request method 'POST' not supported","path":"/feign-get-user"}
- **错误原因：** 
该请求不会成功，只要参数是复杂对象，即使指定了是GET方法，feign依然会以POST方法进行发送请求。可能是我没找到相应的注解或使用方法错误。

- **解决办法：**
```
// 该请求不会成功，只要参数是复杂对象，即使指定了是GET方法，feign依然会以POST方法进行发送请求。可能是我没找到相应的注解或使用方法错误。
@RequestMapping(method = RequestMethod.GET, value = "/feign-get-user")
public User getUser(User user);

//正确用法
@RequestMapping(method = RequestMethod.GET, value = "/feign-get-user")
public User getUser(@RequestParam("id") Long id, @RequestParam("username") String username, @RequestParam("age") String age);
}
```
## Error creating bean with name 'eurekaAutoServiceRegistration'
org.springframework.beans.factory.BeanCreationNotAllowedException: Error creating bean with name 'eurekaAutoServiceRegistration': Singleton bean creation not allowed while singletons of this factory are in destruction (Do not request a bean from a BeanFactory in a destroy method implementation!)
- **错误原因：** 
   - 同一个服务重复启了;
   - 或者是端口被其他应用占用了。
- **解决办法：**
释放被占用的端口即可
## Read timed out
- **详细描述：** com.sun.jersey.api.client.ClientHandlerException: java.net.SocketTimeoutException: Read timed out
- **错误原因：** 
应用刚启动，需要通过ribbon从eureka上拉取服务；需要将虚拟主机名转化为ip地址
- **解决办法：**
这是比较正常的现象，只需要再次刷新就好了
## 解决第一次请求报超时异常的方案
- **错误原因：** 
网络等原因，导致请求时间过长，进而引发timeout的错误
- **解决办法：**
   - 默认时间是超过1秒就是超时，将其设置为5秒
    ```
    hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds: 5000
    ```
   - 禁用超时时间timeout
    ```
    hystrix.command.default.execution.timeout.enabled: false
    ```
   - 索性禁用feign的hystrix支持
    ```
    feign.hystrix.enabled: false  
    ```
   - 超时的issue：https://github.com/spring-cloud/spring-cloud-netflix/issues/768
   - 超时的解决方案： http://stackoverflow.com/questions/27375557/hystrix-command-fails-with-timed-out-and-no-fallback-available
   - hystrix配置： https://github.com/Netflix/Hystrix/wiki/Configuration#execution.isolation.thread.timeoutInMilliseconds 
## Cannot execute request on any known server
- **错误详细描述：** com.netflix.discovery.shared.transport.TransportException: Cannot execute request on any known server
- **错误原因：** 
Peer Awareness配置
```
# application.yml (Two Peer Aware Eureka Servers). 
---
spring:
  profiles: peer1
eureka:
  instance:
    hostname: peer1
  client:
    serviceUrl:
      defaultZone: http://peer2/eureka/

---
spring:
  profiles: peer2
eureka:
  instance:
    hostname: peer2
  client:
    serviceUrl:
      defaultZone: http://peer1/eureka/
```
- **解决办法：**
修改C:\Windows\System32\drivers\etc路径下的hosts文件，在文末加入以下内容：
```
127.0.0.1 peer1 peer2 peer3
```
## com.netflix.client.ClientException: Load balancer does not have available server for client: microservice-provider-user
- **错误原因：** 
消费者调用服务时无服务可用
- **解决办法：**
1. 确定本机是否关闭防火墙
2. 是否导入eureka的jar包
```
<!-- 注册Eureka服务 -->
<dependency>
<groupId>org.springframework.cloud</groupId>
<artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```
3. 确定是否导入hystrix的jar包
```
<!-- 配置hystrix所需依赖的包 -->
<dependency>
<groupId>org.springframework.cloud</groupId>
<artifactId>spring-cloud-starter-netflix-hystrix</artifactId>
</dependency>
```
4. 确定配置文件服务前面是否有空格
![image](https://www.cnblogs.com/images/cnblogs_com/mmzs/1301081/o_QQ%e5%9b%be%e7%89%8720180914170639.png)
## Unable to connect to Command Metric Stream
- **错误原因：** 
配置文件不完整
- **解决办法：**
==Hystrix Metrics Stream==
要启用Hystrix度量标准流，请在spring-boot-starter-actuator上包含依赖项，并设置==management.endpoints.web.exposure.include：hystrix.stream==。 这样做会将 /actuator/hystrix.stream公开为管理端点，如以下示例所示：
   - pom.xml
    ```
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
       
        </dependency>
    ```    
   - application.yml
    ```
        # 配置Hystrix Metrics Stream
        management:
          endpoints:
            web:
              exposure:
                include: hystrix.stream
    ```
## hystrix.stream一直是ping
- **错误原因：** 
   - 因为没有请求任何东西，所以看不到内容;
   - 缺少配置监控的依赖
   - 配置环境不完善
- **解决办法：**
   - 访问一下其他服务,比如http://localhost:9000/goods/2(自己写的一个服务)即可看到内容
   - 客服端添加依赖
   ```
    <!-- Actuator是SpringBoot提供的对应用系统的自省和监控的集成功能，可以查看应用配置的详细信息;
      如果提示 Unable to connect to Command Metric Stream.则需要引入以下包!
     -->
<dependency>
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-actuator</artifactId>
</dependency> 
   ```
   - 完善配置环境
   ```
    # 使用Hystrix Metrics Stream必备 
    management:
      endpoints: 
        web:
          exposure: 
            include: hystrix.stream   
   ```
## turbine.stream一直是ping
- **错误原因：** 
   - 因为没有请求任何东西，所以看不到内容;
   - 缺少配置监控的依赖 
   - Eureka服务注册中心未将自己作为客户端来尝试注册它自己
    ```
    # 注册Eureka服务
    eureka:
      client:
        register-with-eureka: false
        fetch-registry: false
    ```
    - 缺少配置监控的依赖
- **解决办法：**
   - 访问一下其他服务,比如http://localhost:9000/goods/2(自己写的一个服务)即可看到内容
   - 客服端添加依赖
   ```
    <!-- Actuator是SpringBoot提供的对应用系统的自省和监控的集成功能，可以查看应用配置的详细信息;
      如果提示 Unable to connect to Command Metric Stream.则需要引入以下包!
     -->
<dependency>
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-actuator</artifactId>
</dependency> 
   ```
    - Eureka服务注册中心未将自己作为客户端来尝试注册它自己
    ```
    # 注册Eureka服务
    eureka:
      client:
    #    register-with-eureka: false
    #    fetch-registry: false
    ```
    - 添加配置的依赖(作为客服端的都需要配置)
    ```
<dependency>
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-actuator</artifactId>
</dependency> 
```
## Health Indicator访问无结果
- **错误原因：** 
   - 未导入依赖包
   - 版本原因导致访问方式改变了
- **解决办法：**
   - 导入依赖包
   ```
    <dependency>
<groupId>org.springframework.boot</groupId>
<artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
   ```
   - 访问http://localhost:8030/actuator查看
   ```
    {
        "_links": {
            "self": {
                "href": "http://localhost:8030/actuator",
                "templated": false
            },
            "health": {
                "href": "http://localhost:8030/actuator/health",
                "templated": false
            },
            "info": {
                "href": "http://localhost:8030/actuator/info",
                "templated": false
            }
        }
    }
   ```
   - 访问http://localhost:8030/actuator/health即可
## Turbine监控多个服务,配置后,出现只监控到一部分服务情况
- **错误原因：**
   - 配置有问题
- **解决办法：**
   - application.xml配置如下：
    ```
    # 0、配置多个监控服务
    turbine:
      appConfig: microservice-consumer-goods-feign-with-hystrix,microservice-consumer-goods-ribbon-with-hystrix
      clusterNameExpression: "'default'"
    ```
    ```
    # 1、仅配置监控一个服务
    turbine:
      aggregator:
        clusterConfig: MICROSERVICE-CONSUMER-GOODS-RIBBON-WITH-HYSTRIX
      appConfig: microservice-consumer-goods-ribbon-with-hystrix
    ```
    - 各个微服务的Controller配置
    <br>每个微服务均需要加上如下注解：
    ```
    //配置hystrix所需注解
    @EnableCircuitBreaker
    ```
## "description":"No key was installed for encryption service","status":"NO_KEY"
- **错误描述**
```
{
    "description": "No key was installed for encryption service",
    "status": "NO_KEY"
}
```
- **错误原因：** 
   - jce安装有问题
   - 没有配置对应的密钥或未读取到配置文件中的秘钥
   - SpringCloud Config的.yml文件配置有问题

- **解决办法：**
   - 第一种问题：<br>
安装JCE即可解决！<br>
**下载地址**：<br>
JDK 6 JCE<br>
http://www.oracle.com/technetwork/java/javase/downloads/jce-6-download-429243.html
<br>JDK 7 JCE<br>
http://www.oracle.com/technetwork/java/javase/downloads/jce-7-download-432124.html
<br>JDK 8 JCE<br>
http://www.oracle.com/technetwork/java/javase/downloads/jce8-download-2133166.html
<br>**安装方法：**<br>
下载完后，可看到这两个jar包：`local_policy.jar`和`US_export_policy.jar`<br>
替换或新增`%JDK_HOME%\jre\lib\security`目录下的这两个jar。
   - 第二、三个问题：
在`bootstrap.yml`文件中配置秘钥：
```yml
encrypt: 
  key: foobar
```
如果是在`application.yml`中配置秘钥有可能读取不到，依然报该错误
- 查看JCE提供者，和一些相应算法
```java
import java.security.*;

public class JceInfo {
public static void main(String[] args) {
System.out.println("-------列出加密服务提供者-----");
Provider[] pro = Security.getProviders();
for (Provider p : pro) {
System.out.println("Provider:" + p.getName() + " - version:" + p.getVersion());
System.out.println(p.getInfo());
}

System.out.println();
System.out.println("-------列出系统支持的 消息摘要算法：");
for (String s : Security.getAlgorithms("MessageDigest")) {
System.out.println(s);
}

System.out.println();
System.out.println("-------列出系统支持的生成 公钥和 私钥对的算法：");
for (String s : Security.getAlgorithms("KeyPairGenerator")) {
System.out.println(s);
}
}
}
```
## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

## 
- **错误描述**

- **错误原因：** 

- **解决办法：**

