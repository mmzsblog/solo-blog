title: Git的使用
date: '2014-08-05 15:46:45'
updated: '2014-08-05 15:46:45'
tags: [git, 开发工具]
permalink: /articles/2019/08/05/1564991521185.html
---
## git:使用idea拉项目时报错
pull报错时处理顺序：
- pull
- commit
- merge
- commit
- push

## git:初次提交项目
- git init 
- git remote add origin https地址
- git pull origin `master`
- 执行下一句命令之前先完善.gitignore文件可以避免无用文件的提交
- git add .
- git commit -m "说明"
- git push origin `master`
### 再次提交项目
- git add .
- git commit -m "说明"
- git push origin `分支名`

## git:初次下载项目
- git init
- git remote add origin https地址
- git pull origin `master`

## git: 强制提交到仓库
- git push -f origin `master`
<br>**注释：**-f为force，意为：强行、强制。

## 提交到分支
- git checkout -b `分支名`
- git add .
- git commit -m "说明"
- git push origin `分支名`



## .gitignore模板
```
# Compiled class file
*.class

# Log file
*.log

# BlueJ files
*.ctxt

# Mobile Tools for Java (J2ME)
.mtj.tmp/

# Package Files #
*.jar
*.war
*.nar
*.ear
*.zip
*.tar.gz
*.rar

# virtual machine crash logs, see http://www.java.com/en/download/help/error_hotspot.xml
target/
!.mvn/wrapper/maven-wrapper.jar

### STS ###
.apt_generated
.classpath
.factorypath
.project
.settings
.springBeans

### IntelliJ IDEA ###
.idea
*.iws
*.iml
*.ipr
*.log
*.log*

### NetBeans ###
nbproject/private/
build/
nbbuild/
dist/
nbdist/
.nb-gradle/

```