title: unity+lua(lua代码优化)
date: '2019-10-23 15:17:03'
updated: '2019-10-30 13:43:58'
tags: [游戏开发, 代码优化]
permalink: /articles/2019/10/23/1571815023009.html
---
换新工作已经一个多月了，每天工作都是那么的充实，也学习到了许多东西，下面总结一下关于代码的优化：

字符串的拼接使用string.format().原因有
(1)避免拼接过程中产生新的字符串占用内存空间
(2)在多语言版本中方便控制语言
在使用for循环的时候,避免重复加载同一资源,避免重复进行相同的运算
例如:
优化前：
```
for i = 1, table.getn(myTable) do
    local myBItem = utils.addchild(group, Asset:LoadAsset(asseturi.getassetpath("timelimitactive", "feedPet/Active53MyBItem")))
end
```
优化后：
```
local len = table.getn(myTable)
local res = Asset:LoadAsset(asseturi.getassetpath("timelimitactive", "feedPet/Active53MyBItem"))
for i = 1, len do
    local myBItem = utils.addchild(group, res)
end
```
在同一界面中,如果有多个东西需要计时,可使用一个计时器,在计时器里进行for循环即可.方法如下:
在需要计时的地方为时间赋值,检测当前计时器是否开启,未开启则调用计时器,当某个计时结束时,将其赋空
代码实现:
```
--计时器
local function setTime()
    this.coroutine = coroutine.start(function()
        while true do
            if this.gameObject == nil then
                return
            end
            --this.lessTime存放对应文本的计时器
            for k, v in pairs(this.lessTime or {}) do
                if v < 1 then
                    --某倒计时结束
                    this.mainTmType[k] = nil
                else
                    this.lessTime[k] = this.lessTime[k] - 1
                    tm.text=this.lessTime[k]--显示
                end
            end
            coroutine.wait(1)
        end
    end)
end
--倒计时赋值
this.lessTime={}
for i = 1, 4 do
    this.lessTime[i]=30
end
--调用
if this.coroutine == nil then
    setTime()
end
```
