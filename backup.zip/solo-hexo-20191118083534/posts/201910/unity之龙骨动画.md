title: unity之龙骨动画
date: '2019-10-23 19:22:12'
updated: '2019-10-30 13:44:32'
tags: [游戏开发, 动画]
permalink: /articles/2019/10/23/1571829732670.html
---
>><font color="#800080" size="6px" face="宋体">**推荐阅读：**</font>
>- <font size="4px" face="楷体">&nbsp;[我的CSDN](https://blog.csdn.net/shirln)</font>
>- <font size="4px" face="楷体">&nbsp;[我的博客园](https://www.cnblogs.com/shirln/)</font>
>- <font size="4px" face="楷体">&nbsp;[QQ群：704621321](http://qm.qq.com/cgi-bin/qm/qr?k=HLQSQCMupMEvLxd7S061X-zpBi8Oo7pM)</font>
>- <font size="4px" face="楷体">&nbsp;[我的个人博客](https://www.mmzsblog.cn/category/%E6%B8%B8%E6%88%8F%E5%BC%80%E5%8F%91)</font>

做游戏有史以来，第一次接触到龙骨动画，为新人引个路吧。
（1）首先拿到美术给我三个文件，分别是name_ske.json，name_tex.json和name_tex
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191303601.png)
（2）在unity中创建一个文件夹，命名为shirln，放入（1）中的三个文件
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191330429.png)
（3）选中（2）中的三个文件，鼠标右键选择“create——>DragonBones——>ArmatureObject(UGUI)”
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191436380.png)
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191539373.png)
（4）这时在Hierarchy面板会生成一个名为Armature的游戏物体
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191556876.png)
（5）修改(4)物体上的UnityArmatureComponent属性如下，并保存为预置放在shirln文件中
![在这里插入图片描述](https://img-blog.csdnimg.cn/20191023191628421.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NoaXJsbg==,size_16,color_FFFFFF,t_70)
（6）代码中使用
a.实例化
b.取UnityArmatureComponent组件
c.Arma.animation:Play("newAnimation", 0)播放(0代表循环)
###### 注意:龙骨动画一定要保存为预置，需要的时候动态加载，不然当多个地方同时使用一个龙骨动画时会出现同一龙骨动画只有一个龙骨动画播放这种情况
