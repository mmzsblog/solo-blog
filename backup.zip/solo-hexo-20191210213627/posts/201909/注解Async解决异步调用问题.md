title: 注解@Async解决异步调用问题
date: '2019-09-20 15:47:12'
updated: '2019-09-20 16:06:55'
tags: [注解]
permalink: /articles/2019/09/20/1568965632142.html
---
## 序言：Spring中@Async

根据Spring的文档说明，默认采用的是单线程的模式的。所以在Java应用中，绝大多数情况下都是通过同步的方式来实现交互处理的。

那么当多个任务的执行势必会相互影响。例如，如果A任务执行时间比较长，那么B任务必须等到A任务执行完毕后才会启动执行。又如在处理与第三方系统交互的时候，容易造成响应迟缓的情况，之前大部分都是使用多线程来完成此类任务，其实，在`spring3.x`之后，已经内置了@Async来完美解决这个问题。

## 1. 何为异步调用？
在解释之前，我们先来看二者的定义：
### 同步调用：顺序执行，需等待上一个任务执行完毕
就是整个处理过程顺序执行，当各个过程都执行完毕，并返回结果。 

### 异步调用：接收到指令就执行，无需等待
则是只是发送了调用的指令，调用者无需等待被调用的方法完全执行完毕；而是继续执行下面的流程。

例如， 在某个调用中，需要顺序调用A,B,C三个过程方法：
如他们都是同步调用，则需要将他们都顺序执行完毕之后，方算作过程执行完毕；如B为一个异步的调用方法，则在执行完A之后，调用B，并不等待B完成，而是执行开始调用C，待C执行完毕之后，就意味着这个过程执行完毕了。

如图所示：
![image.png](https://img.hacpai.com/file/2019/09/image-d63512d3.png)


## 2. 常规的异步调用处理方式
在Java中，一般在处理类似的场景之时，都是基于创建独立的线程去完成相应的异步调用逻辑，通过主线程和不同的线程之间的执行流程，从而在启动独立的线程之后，主线程继续执行而不会产生停滞等待的情况。或是使用TaskExecutor执行异步线程，参看http://www.cnblogs.com/wihainan/p/6098970.html。

 

## 3. 如何在Spring中启用@Async？
### 3.0、@Async介绍
在Spring中，基于@Async标注的方法，称之为异步方法；这些方法在执行的时候，将会在独立的线程中被执行，调用者无需等待它的完成，即可继续其他的操作。

### 3.1、启用`@Async`注解
#### 3.1.1、基于Java配置的启用方式：
```java
@Configuration  
@EnableAsync  
public class SpringAsyncConfig { ... }  
```
#### 3.1.2、基于SpringBoot配置的启用方式：
```java
@SpringBootApplication
@EnableAsync
public class SpringBootApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootApplication.class, args);
    }
}
```
### 3.2、使用`@Async`注解，声明方法为异步调用
#### 3.2.0、在无返回值方法上使用：
在方法上申明为异步调用方法即可
```java
    @Async //标注使用
    public void downloadFile() throws Exception { ... } 
```
#### 3.2.1、在有返回值方法上使用：
```
@Async  
public Future<String> asyncMethodWithReturnType() {  
    System.out.println("Execute method asynchronously - "  + Thread.currentThread().getName());  
    try {  
        Thread.sleep(5000);  
        return new AsyncResult<String>("hello world !!!!");  
    } catch (InterruptedException e) {  
        //  
    }  
   
    return null;  
}
```
以上示例可以发现，返回的数据类型为Future类型，其为一个接口。具体的结果类型为AsyncResult,这个是需要注意的地方。

调用返回结果的异步方法示例:
```
public void testAsyncAnnotationForMethodsWithReturnType()  
   throws InterruptedException, ExecutionException {  
    System.out.println("Invoking an asynchronous method. "   + Thread.currentThread().getName());  
    Future<String> future = asyncAnnotationExample.asyncMethodWithReturnType();  
   
    while (true) {  ///这里使用了循环判断，等待获取结果信息  
        if (future.isDone()) {  //判断是否执行完毕  
            System.out.println("Result from asynchronous process - " + future.get());  
            break;  
        }  
        System.out.println("Continue doing something else. ");  
        Thread.sleep(1000);  
    }  
}
```
这些获取异步方法的结果信息，是通过不停的检查Future的状态来获取当前的异步方法是否执行完毕来实现的。

 

## 4. 基于@Async调用中的异常处理机制
在异步方法中，如果出现异常，对于调用者caller而言，是无法感知的。如果确实需要进行异常处理，则按照如下方法来进行处理：

- 自定义实现AsyncTaskExecutor的任务执行器
在这里定义处理具体异常的逻辑和方式。
- 配置由自定义的TaskExecutor替代内置的任务执行器<br>
示例步骤1，自定义的TaskExecutor
```
public class ExceptionHandlingAsyncTaskExecutor implements AsyncTaskExecutor {  
    private AsyncTaskExecutor executor;  
    public ExceptionHandlingAsyncTaskExecutor(AsyncTaskExecutor executor) {  
        this.executor = executor;  
     }  
      ////用独立的线程来包装，@Async其本质就是如此  
    public void execute(Runnable task) {       
      executor.execute(createWrappedRunnable(task));  
    }  
    public void execute(Runnable task, long startTimeout) {  
        /用独立的线程来包装，@Async其本质就是如此  
       executor.execute(createWrappedRunnable(task), startTimeout);           
    }   
    public Future submit(Runnable task) { return executor.submit(createWrappedRunnable(task));  
       //用独立的线程来包装，@Async其本质就是如此。  
    }   
    public Future submit(final Callable task) {  
      //用独立的线程来包装，@Async其本质就是如此。  
       return executor.submit(createCallable(task));   
    }   
      
    private Callable createCallable(final Callable task) {   
        return new Callable() {   
            public T call() throws Exception {   
                 try {   
                     return task.call();   
                 } catch (Exception ex) {   
                     handle(ex);   
                     throw ex;   
                   }   
                 }   
        };   
    }  
  
    private Runnable createWrappedRunnable(final Runnable task) {   
         return new Runnable() {   
             public void run() {   
                 try {  
                     task.run();   
                  } catch (Exception ex) {   
                     handle(ex);   
                   }   
            }  
        };   
    }   
    private void handle(Exception ex) {  
      //具体的异常逻辑处理的地方  
      System.err.println("Error during @Async execution: " + ex);  
    }  
}
```
分析： 可以发现其是实现了AsyncTaskExecutor, 用独立的线程来执行具体的每个方法操作。在createCallable和createWrapperRunnable中，定义了异常的处理方式和机制。

`handle()`就是未来我们需要关注的异常处理的地方。 
xml配置文件中的内容：
```
<task:annotation-driven executor="exceptionHandlingTaskExecutor" scheduler="defaultTaskScheduler" />  
<bean id="exceptionHandlingTaskExecutor" class="nl.jborsje.blog.examples.ExceptionHandlingAsyncTaskExecutor">  
    <constructor-arg ref="defaultTaskExecutor" />  
</bean>  
<task:executor id="defaultTaskExecutor" pool-size="5" />  
<task:scheduler id="defaultTaskScheduler" pool-size="1" />
```
也可以使用注解的形式将其配置注册到bean中。
## 5. @Async调用中的事务处理机制
在`@Async`标注的方法，同时也使用`@Transactional`进行标注；在其调用数据库操作之时，将无法产生事务管理的控制，原因就在于其是基于异步处理的操作。

那该如何给这些操作添加事务管理呢？

可以将需要事务管理操作的方法放置到异步方法内部，在内部被调用的方法上添加`@Transactional`

### 示例：  
**方法A，** 使用了`@Async`/`@Transactional`来标注，但是无法产生事务控制的目的。

**方法B，** 使用了`@Async`来标注，B中调用了C、D，C/D分别使用`@Transactional`做了标注，则可实现事务控制的目的。

## 6. 参考文章：
[1]https://www.cnblogs.com/wihainan/p/6516858.html
[2]http://www.cnblogs.com/wihainan/p/6098970.html
