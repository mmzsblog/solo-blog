title: draw call 有关的参数
date: '2019-08-29 21:37:14'
updated: '2019-08-29 21:37:14'
tags: [游戏开发, Unity优化]
permalink: /articles/2019/08/29/1567085834529.html
---
![](https://img.hacpai.com/bing/20190518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


### [Unity 优化(一) ------ 优化前了解以及方向](https://blog.csdn.net/dengshunhao/article/details/82527506)
FPS：画面每秒传输帧数,，要避免动作不流畅的最低是30；值越大性能越好
CPU：计算每帧需要消耗的时间，值越低说明计算越快，值越小性能越好
Batches：将某些DrawCalls合并，数量为合并后DrawCall的数量。
Tris：三角面
Verts：顶点
SetPass call：Shader中Cpu每次运行Pass之前都会产生一个SetPass call。

### [Unity 优化(二) ------ 资源优化](https://blog.csdn.net/dengshunhao/article/details/82663719)
长时间音乐使用Mp3格式（使用压缩格式），例如：背景音乐等
短时间音乐使用wav格式（不使用压缩格式），例如：音效
![在这里插入图片描述](https://img.hacpai.com/file/2019/08/20190829211522364-a9ed4237.png)

**减少冗余资源和重复资源**
A、Resources目录下的资源不管是否被引用，都会打包进安装包
      不使用的资源不要放在Resources目录下
B、不同目录下的相同资源文件，如果都被引用，那么都会打包进资源包，造成冗余
      保证同一个资源文件在项目中只存放在一个目录位置
