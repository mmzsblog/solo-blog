title: SpringCloud（三）：Hystrix-有界面和无界面的配置
date: '2019-08-06 15:51:12'
updated: '2019-08-06 15:52:07'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565077872515.html
---

# Hystrix
## Propagating the Security Context or Using Spring Scopes
如果您希望某些线程本地上下文传播到@HystrixCommand，则默认声明不起作用，因为它在线程池中执行该命令（如果超时）。您可以通过配置或直接在注释中切换Hystrix，以使用与调用者相同的线程，方法是要求它使用不同的“隔离策略”。
- 示例：
   - 演示如何在注释中设置线程：

```
    @RestController
    public class GoodsController {
     @Autowired
     private RestTemplate restTemplate;
    
     @GetMapping("/goods/{id}")
     //fallbackMethod定义的方法的参数名和返回值一定要和原参数一致
     @HystrixCommand(fallbackMethod = "findByIdFallback")
     public User findById(@PathVariable Long id) {
     return this.restTemplate.getForObject("http://microservice-provider-user/user/" + id, User.class);
     }
    
     public User findByIdFallback(Long id){
     User user = new User();
     user.setId(0L);
     user.setUsername("zhang三");
     return user;
     }
    
    }
```

一般首先不配置commandProperties ，如果遇到运行时异常，表示无法找到作用域上下文，则需要使用相同的线程，才需要配置。
因为请求是一个线程，@HystrixCommand是一个隔离的线程；
如果您使用@SessionScope或@RequestScope，也能达到同样的效果。
- 使用commandProperties
```
@RestController
public class GoodsController {
@Autowired
private RestTemplate restTemplate;

@GetMapping("/goods/{id}")
//fallbackMethod定义的方法的参数名和返回值一定要和原参数一致
@HystrixCommand(fallbackMethod = "findByIdFallback", commandProperties = { @HystrixProperty(name="execution.isolation.strategy", value="SEMAPHORE")} )
//commandProperties = @HystrixProperty(name="execution.isolation.strategy", value="SEMAPHORE")
//一般首先不做配置，如果遇到运行时异常，表示无法找到作用域上下文，则需要使用相同的线程，才需要配置。
//因为请求是一个线程，@HystrixCommand是一个隔离的线程,由于不在同一个线程，容易导致找不到上下文
//如果您使用@SessionScope或@RequestScope，也能达到同样的效果。
public User findById(@PathVariable Long id) {
return this.restTemplate.getForObject("http://microservice-provider-user/user/" + id, User.class);
}

public User findByIdFallback(Long id){
User user = new User();
user.setId(0L);
user.setUsername("zhang三");
return user;
}
```
- 使用@SessionScope或@RequestScope
```
@RestController
@SessionScope
@Scope("session")
public class GoodsController {
@Autowired
private RestTemplate restTemplate;

@GetMapping("/goods/{id}")
@HystrixCommand(fallbackMethod = "findByIdFallback" )
public User findById(@PathVariable Long id) {
return this.restTemplate.getForObject("http://microservice-provider-user/user/" + id, User.class);
}

public User findByIdFallback(Long id){
User user = new User();
user.setId(0L);
user.setUsername("zhang三");
return user;
}

}
```
==**注：**== 了解scope的分类：[Spring Scope](https://blog.csdn.net/cuidiwhere/article/details/7856809)
<br>
## 监控Hystrix界面:Hystrix dashboard 和 Turbine
链接：https://blog.csdn.net/hry2015/article/details/78617954
## Hystrix Metrics Stream
要启用Hystrix度量标准流，请在==spring-boot-starter-actuator==上包含依赖项，并设置==management.endpoints.web.exposure.include：hystrix.stream==。 这样做会将 ==/actuator/hystrix.stream==公开为管理端点，如以下示例所示：<br>
- pom.xml
```
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-actuator</artifactId>
    </dependency>
```
- application.yml
```
    # 配置Hystrix Metrics Stream
    management:
      endpoints:
        web:
          exposure:
            include: hystrix.stream
```
## Hystrix Dashboard
- pom.xml添加依赖
```
<!-- hystrix dashboard -->
<dependency>
<groupId>org.springframework.cloud</groupId>
<artifactId>spring-cloud-starter-netflix-hystrix-dashboard</artifactId>
</dependency>
```
- 启动类添加Hystrix Dashboard注解
```
@EnableHystrixDashboard
```
## Hystrix Turbine
- 概念
   - 一个准实时的集群界面监控工具
   - 有一定的延迟
   - 因为取服务需要一定的时间
- 如何使用
   - pom.xml添加依赖
    ```
     <!-- hystrix turbine -->
     <dependency>
     <groupId>org.springframework.cloud</groupId>
     <artifactId>spring-cloud-starter-netflix-turbine</artifactId>
     </dependency>
    ```
   - 启动类添加Hystrix Turbine注解
    ```
        @EnableTurbine
    ```
   - application.xml
    ```
    # 配置turbine
    turbine:
      aggregator:
        clusterConfig: MICROSERVICE-CONSUMER-GOODS-RIBBON-WITH-HYSTRIX
      appConfig: microservice-consumer-goods-ribbon-with-hystrix
    ```

