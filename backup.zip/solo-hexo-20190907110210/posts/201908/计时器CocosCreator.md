title: 计时器（CocosCreator）
date: '2019-08-09 17:32:44'
updated: '2019-08-09 17:34:22'
tags: [游戏开发, CocosCreator]
permalink: /articles/2019/08/09/1565343164154.html
---
>><font color="#800080" size="6px" face="宋体">**推荐阅读：**</font>
>- <font size="4px" face="楷体"> [我的CSDN](https://blog.csdn.net/shirln)</font>
>- <font size="4px" face="楷体"> [我的博客园](https://www.cnblogs.com/shirln/)</font>
>- <font size="4px" face="楷体"> [QQ群：704621321](http://qm.qq.com/cgi-bin/qm/qr?k=HLQSQCMupMEvLxd7S061X-zpBi8Oo7pM)</font>

      在游戏中，经常会涉及到计时的功能，主要是倒计时。倒计时通常用在某项活动距离结束的剩余时间以及距离开始某项活动开始的时间。对于不同的游戏引擎，提供的计时方法也有所差异。最近正在使用CocosCreator开发项目，恰好也遇到了该需求，就来聊聊CocosCreator中计时功能的实现方法：
在CocosCreator中，提供了一个方法：
```js
cc.repeatForever();
```
      对于这个方法的解释是：永远地重复一个动作，有限次数内重复一个动作请使用 repeat 动作由于这个动作不会停止，所以不能被添加到 cc.sequence 或 cc.spawn 中。
下面就是用该方法来实现计时效果：

```js
 countDown(time) {
        var self = this;
        
        var call1 = app.callFunc(function (adt) {
            time = time - 1;
            cc.log("当前倒计时时间为：", time);
            if (time <= 0) {
                cc.log("倒计时结束~~~");
                self.uiRoot.countdown.stopAllActions();
            }
            self.uiRoot.txt_countdown.string = "" + self.formatTime(Math.max(0, time));
        }, self.uiRoot.countdown);
        
        var delay = cc.delayTime(1);
        self.uiRoot.countdown.runAction(cc.repeatForever(cc.sequence(call1, delay)));
    },
```
      上面的方法其实就是通过顺序执行一系列事情（time--），来达到计时的效果。其中self.uiRoot.countdown是计时文本的父节点，self.uiRoot.txt_countdown是计时器的显示文本。
      上面代码中的formatTime()方法，是通过给定一个时间值（秒），来转换为()天()时()分()秒，当然，你也可以通过实际情况决定返回的单位。formatTime代码如下：

```js
    /// 计算时间格式
    formatTime(tm) {
        var d = Math.floor(tm / 86400)
        var h = Math.floor(tm % 86400 / 3600);
        var m = Math.floor(tm % 3600 / 60);

        var s = Math.floor(tm % 60);
        // return "{0}{1}{2}{3}".format(d > 0 ? ("" + d + "天") : "", h > 0 ? ("" + h + "时") : "", m > 0 ? ("" + m + "分") : "", s > 0 ? ("" + s + "秒") : "0秒");

        if (tm < 60) { return s; }
        return "{0}{1}{2}".format(d > 0 ? ("" + d + "天") : "", h > 0 ? ("" + h + "时") : "", m > 0 ? ("" + m + "分") : "");
    },
```


当然，计时的方法肯定不止这一种，这只是实现计时器的一个方法，选择这个方法的原因时我觉得比较简单，易懂，如果你有更好的方法，欢迎屏幕下方留言~~