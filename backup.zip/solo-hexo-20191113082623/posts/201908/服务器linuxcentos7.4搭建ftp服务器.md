title: 服务器linux centos 7.4 搭建ftp服务器
date: '2019-08-20 21:52:22'
updated: '2019-08-20 21:52:22'
tags: [Linux]
permalink: /articles/2019/08/20/1566309142008.html
---
此操作是在腾讯云服务器linux centos 7.4 完成搭建ftp服务器 vsftpd 的； 
# 安装 vsftpd
$ yum install vsftpd -y

# 启动
$ service vsftpd start && systemctl restart vsftpd.service
# 关闭
service vsftpd stop && systemctl stop vsftpd.service

# 查看
$ netstat -nltp | grep 21
```
/*
目前 FTP 服务登陆允许匿名登陆，也无法区分用户访问，我们需要配置 FTP 访问权限
vsftpd 的配置目录为 /etc/vsftpd，包含下列的配置文件：
vsftpd.conf 为主要配置文件
ftpusers 配置禁止访问 FTP 服务器的用户列表
user_list 配置用户访问控制
*/
```
# 修改权限
$ vi /etc/vsftpd/vsftpd.conf
修改内容如下:
```
# 禁用匿名用户
anonymous_enable=NO
# 禁止切换根目录
chroot_local_user=YES
```
# 重启后 pub/目录访问需要登录了
$ service vsftpd restart && systemctl restart vsftpd.service

# 创建 FTP 用户
$ useradd ftpuser

# 为用户 ftpuser 设置密码
$ echo "ftpuser" | passwd ftpuser --stdin
```
# 限制该用户仅能通过 FTP 访问
# 限制用户 ftpuser 只能通过 FTP 访问服务器，而不能直接登录服务器
```
$ usermod -s /sbin/nologin ftpuser

# 为用户分配主目录 为用户 ftpuser 创建主目录 并约定：/data/ftp 为主目录, 该目录不可上传文件
```
#创建 /data/ftp/pub 目录
```
$ mkdir -p /data/ftp/pub
```
#写欢迎使用ftp服务文件 /data/ftp/welcome.txt
```
$ echo "Welcome to use FTP service." > /data/ftp/welcome.txt

# 设置访问权限 chmod a-w 表示不可写(all-write)
$ chmod a-w /data/ftp && chmod 777 -R /data/ftp/pub

# 设置为用户主目录
$ usermod -d /data/ftp ftpuser

# 重启服务器
$ sudo systemctl restart vsftpd.service

# 登录FTP
资源管理器打开 ftp://ftpuser:ftpuser@IP
FTP软件登录 主动,被动都可以
