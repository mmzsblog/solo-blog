title: 玩转SpringBoot之MyBatisplus自动化构建工具
date: '2019-08-08 11:54:18'
updated: '2019-08-08 15:23:04'
tags: [玩转SpringBoot]
permalink: /articles/2019/08/08/1565236458796.html
---
![](https://img.hacpai.com/bing/20190109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 使用MyBatisplus自动化构建项目
### 为什么要用这个？
- 方便
- 因为之前那种方式让我用起来不爽了：[mybatis逆向工程（MyBatis Generator）](https://www.cnblogs.com/mmzs/p/8391289.html)
- 能紧密的贴合mybatis，并且MyBatisplus的很多api用起来也更加方便，能大大提高开发效率

### 开始使用
0、构建一个普通的Maven工程，这里就不再赘述了<br>
1、导包：导入需要使用到的依赖
```xml
<dependencies>
    <!-- mybatisplus生成工具需要的依赖 -->
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus-generator</artifactId>
        <version>3.0.6</version>
        <scope>compile</scope>
    </dependency>
    <!-- 模板引擎 -->
    <dependency>
        <groupId>org.apache.velocity</groupId>
        <artifactId>velocity</artifactId>
        <version>1.7</version>
        <scope>test</scope>
    </dependency>
    <dependency>
        <groupId>org.apache.velocity</groupId>
        <artifactId>velocity-engine-core</artifactId>
        <version>2.0</version>
    </dependency>
    <!-- 模板依赖了日志，所以需要该包 -->
    <dependency>
        <groupId>org.slf4j</groupId>
        <artifactId>slf4j-api</artifactId>
        <version>1.7.25</version>
    </dependency>

    <!-- Spring依赖，否则@Service等注解会报错 -->
    <dependency>
        <groupId>org.springframework</groupId>
        <artifactId>spring</artifactId>
        <version>2.5.6.SEC03</version>
    </dependency>

    <!-- 数据库连接依赖-->
    <!--添加MySql依赖 -->
    <!--
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <version>5.1.42</version>
    </dependency>
    -->
    <!-- 添加Oracle依赖 -->
    <dependency>
        <groupId>com.oracle</groupId>
        <artifactId>ojdbc6</artifactId>
        <version>11.2.0.3</version>
    </dependency>

    <!-- Mybatis Plus Dependencies -->
    <dependency>
        <groupId>com.baomidou</groupId>
        <artifactId>mybatis-plus</artifactId>
        <version>3.0.7.1</version>
    </dependency>

</dependencies>
```
此处要注意的一点就是：因为使用的是MyBatisplus的自动化构建工具，故在引入的依赖中，不再使用mybatis的依赖包：
```xml
<!--添加Mybatis依赖 配置mybatis的一些初始化的东西-->
<dependency>
<groupId>org.mybatis.spring.boot</groupId>
<artifactId>mybatis-spring-boot-starter</artifactId>
<version>1.3.2</version>
</dependency>
```
而是需要使用MyBatisplus的依赖包：
```xml
<!-- Mybatis Plus Dependencies -->
<dependency>
    <groupId>com.baomidou</groupId>
    <artifactId>mybatis-plus</artifactId>
    <version>3.0.7.1</version>
</dependency>
```
2、自动化构建工具类
```
package com.java.mmzsit;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import java.lang.reflect.Field;

/**
 * @author ：mmzsit
 * @description：MyBatisplus自动化构建工具
 * @date ：2019/6/14 14:45
 */

public class generator {
    public static void main(String[] args) throws Exception {
        AutoGenerator mpg = new AutoGenerator();
        // TODO 此处务必记得修改
        String outputDir = "D:\\WorkspaceGit\\mybatisPlus-generator\\src\\main\\java";

        // 全局配置
        GlobalConfig gc = new GlobalConfig();
        gc.setOutputDir(outputDir);
        gc.setFileOverride(true);
        gc.setActiveRecord(true);
        // XML 二级缓存
//        gc.setEnableCache(true);
        // XML ResultMap
        gc.setBaseResultMap(true);
        // XML columList
        gc.setBaseColumnList(true);
        gc.setAuthor("mmzsit");

        // 自定义文件命名，注意 %s 会自动填充表实体属性！
        gc.setMapperName("I%sMapper");
        gc.setXmlName("%sMapper");
        gc.setServiceName("I%sService");
        gc.setServiceImplName("%sServiceImpl");
        gc.setControllerName("%sController");
        mpg.setGlobalConfig(gc);

        // 数据源配置mysql
//        DataSourceConfig dsc = new DataSourceConfig();
//        dsc.setDbType(DbType.MYSQL);
//        dsc.setDriverName("com.mysql.jdbc.Driver");
//        dsc.setUrl("jdbc:mysql://localhost:3306/itresources?useUnicode=true&characterEncoding=UTF-8&generateSimpleParameterMetadata=true");
//        dsc.setUsername("root");
//        dsc.setPassword("123456");
//        mpg.setDataSource(dsc);
        // 数据源配置oracle
        DataSourceConfig dsc = new DataSourceConfig();
        dsc.setDbType(DbType.ORACLE);
        dsc.setDriverName("oracle.jdbc.OracleDriver");
        dsc.setUrl("jdbc:oracle:thin:@localhost:1521/ORCL");
        dsc.setUsername("mmzsit");
        dsc.setPassword("mmzsit");
        mpg.setDataSource(dsc);


        // 策略配置
        StrategyConfig strategy = new StrategyConfig();
        // 表名生成策略
        strategy.setNaming(NamingStrategy.underline_to_camel);
        // 需要生成的表,大小写一定要正确
        strategy.setInclude(new String[]{"TESTDATAS"});
        // 排除生成的表
//        strategy.setExclude(new String[]{"order"});
        Field field = strategy.getClass().getDeclaredField("logicDeleteFieldName");
        field.setAccessible(true);
        field.set(strategy, "logic_del");
        mpg.setStrategy(strategy);

        // 包配置
        PackageConfig pc = new PackageConfig();
        pc.setParent("com.java.mmzsit");
//        pc.setModuleName("dc");
        mpg.setPackageInfo(pc);

        // 执行生成
        mpg.execute();
        System.out.println("自动构建完成！");
    }

}
```
运行上面的java代码，即可完成一次自动化构建；<br>

3、值得注意的一点<br>
在.yml配置文件中，也不再使用：
```yml
mybatis:
  # mapper映射文件
  mapper-locations: classpath:mapper/*Mapper.xml
```
而是使用的配置写法：
```yml
mybatis-plus:
  # mapper映射文件
  mapper-locations: classpath:mapper/*Mapper.xml
```
### 构建完成后，生成代码效果图
![效果图](https://img.hacpai.com/file/2019/08/1196304-022d6f91.png)


### 总结
相对而言，使用这种方式自动化构建方便快捷；而且后期维护也很简易。但唯一不舒服的就是生成的实体类还是使用的get、set的方式构建的，而不是使用lombok构建的。
<br>
代码已经提交github：[mybatisPlus-generator](https://github.com/mmzsblog/mybatisPlus-generator)
<br><br>
