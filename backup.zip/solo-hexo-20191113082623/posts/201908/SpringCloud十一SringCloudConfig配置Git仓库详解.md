title: SpringCloud（十一）：SringCloud Config-配置Git仓库详解
date: '2019-08-06 15:56:22'
updated: '2019-08-06 15:56:22'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565078182745.html
---
## Git仓库配置详解
- 使用git的几个好处：<br>
   - 可以做版本审计：做了修改可以查看历史记录，查看是谁修改的等;
   - 用来做分布式等都比较方便，像用本地文件存储,就不能高可用，除非再弄一个nfs或者其他的分布式的文件系统
   - 官方也建议使用git

参考地址：[Finchley.SR2文档](https://cloud.spring.io/spring-cloud-static/Finchley.SR2/single/spring-cloud.html#_git_backend)

### 基础使用方式
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test
```
### 通配符
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
  # {application}表示根据应用名称寻找配置信息
          uri: https://gitee.com/mmzs/{application}
```
### 模式匹配和多个存储库
#### 模式匹配
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
  # 公用；即当simple和special都匹配不到时，就是用该仓库下的配置信息
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test      
            simple: https://gitee.com/mmzs/simple
            special:
  # 请求时使用：localhost:8080/mmzs/special-dev.properties
  # 请求时使用：localhost:8080/mmzs/special-test.properties
              pattern: special*/dev*,special*/test*
              uri: https://gitee.com/mmzs/special
```
#### 搜索路径
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test      # 公用
          search-paths:
            - foo   # foo路径
            - bar   # bar路径
```
#### cloneOnStart属性的使用
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test      # 公用
  # 默认是false；即启动时不会连git仓库，把需要的资源都下载下来；而是首次请求的时候才下载
          clone-on-start: true  
          repos:
            simple: https://gitee.com/mmzs/simple
            special:
              pattern: special*/dev*,special*/test*
              uri: https://gitee.com/mmzs/special
              cloneOnStart: false   # 默认是false
```
### 账号密码配置
```
server:
  port: 8080
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test
          username: xxx
          password: xxx
```
### 占位符在Git搜索路径中的使用
Spring Cloud Config Server还支持带有占位符的搜索路径，用于{application}和{profile}（以及{label}，如果需要），如以下示例所示：
```
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test
          searchPaths: '{application}'
```
上面的配置导致在存储库中搜索与目录（以及顶层）同名的文件，通配符在带占位符的搜索路径中也有效（搜索中包含任何匹配的目录）。 
