title: Linux之acl库的安装与使用（限制Linux某用户的访问权限）
date: '2019-09-09 14:05:16'
updated: '2019-09-09 14:07:49'
tags: [Linux]
permalink: /articles/2019/09/09/1568009115960.html
---
## acl库
作用：限制Linux某用户的访问权限

## acl库的安装
1. 首先github中下载acl代码：
```
git clone https://github.com/acl-dev/acl
```
2. 进入acl， 执行make
```   
cd acl 
make
```
注意: [因为`acl`是由`c/c++`编写的，需要提前安装好`gcc`, `g++`]

3. 安装到用户根目录：
```
make packinstall
```
一般到这儿就能编译安装成功了，在`/user/include/` 目录下会有acl-lib目录。
4.  如果是`centos`系统，可直接安装
```
yum install zlib-devel
```

## setfacl命令的基本用法
### 1、setfacl的用途
setfacl命令可以用来细分linux下的文件权限。 
chmod命令可以把文件权限分为u,g,o三个组，而setfacl可以对每一个文件或目录设置更精确的文件权限。 
换句话说，setfacl可以更精确的控制权限的分配。 
比如：让某一个用户对某一个文件具有某种权限。

这种独立于传统的u,g,o的rwx权限之外的具体权限设置叫ACL（Access Control List） 
ACL可以针对单一用户、单一文件或目录来进行r,w,x的权限控制，对于需要特殊权限的使用状况有一定帮助。 
如，某一个文件，不让单一的某个用户访问。
### 2、setfacl的用法
```
用法: setfacl [-bkndRLP] { -m|-M|-x|-X ... } file ...
-m,       --modify-acl 更改文件的访问控制列表
-M,       --modify-file=file 从文件读取访问控制列表条目更改
-x,       --remove=acl 根据文件中访问控制列表移除条目
-X,       --remove-file=file 从文件读取访问控制列表条目并删除
-b,       --remove-all 删除所有扩展访问控制列表条目
-k,       --remove-default 移除默认访问控制列表
          --set=acl 设定替换当前的文件访问控制列表
          --set-file=file 从文件中读取访问控制列表条目设定
          --mask 重新计算有效权限掩码
-n,       --no-mask 不重新计算有效权限掩码
-d,       --default 应用到默认访问控制列表的操作
-R,       --recursive 递归操作子目录
-L,       --logical 依照系统逻辑，跟随符号链接
-P,       --physical 依照自然逻辑，不跟随符号链接
          --restore=file 恢复访问控制列表，和“getfacl -R”作用相反
          --test 测试模式，并不真正修改访问控制列表属性
-v,       --version           显示版本并退出
-h,       --help              显示本帮助信息
```
### 3、几个例子
查看mysql-5.5.32安装目录的acl
#### 查看
```
[root@localhost software]# getfacl mysql-5.5.32
# file: mysql-5.5.32
# owner: mysql
# group: mysql
user::rwx
user:mysql:r-x
group::r-x
group:mysql:r-x
mask::r-x
other::r-x
```
#### 修改
- 设置默认用户，读，写，可执行
```
[root@localhost ~]# setfacl -m u::rwx test   
```

- 修改文件的acl权限，添加一个用户权限
```
[root@localhost ~]# setfacl -m u:mmzs:rw- test    
```
- 添加一个组
```
[root@localhost ~]# setfacl -m g:mmzsit:r-w test  
```

- 给mmzs用户向test文件增加读和执行的acl规则
```
[root@localhost ~]# setfacl -m u:mmzs:rx test     
```
- 给mmzsit用户向test文件增加读和执行的acl规则
```
[root@localhost ~]# setfacl -m u:mmzsit:rx test 
```

#### 移除
- 移除mysql-5.5.32目录的root组和root用户的acl规则
```
[root@localhost software]# setfacl -R -x g:root /software/mysql-5.5.32/
[root@localhost software]# setfacl -R -x u:root /software/mysql-5.5.32/
```

- 清除tank用户，对test文件acl规则
```
[root@localhost ~]# setfacl -x u:mmzs test    
```

- 清除所有acl
```
[root@localhost ~]# setfacl -b test     
```
## 说明事项：
- 设置组的话只需要把setfacl -m u::rwx 中的u改为g即可，大致差不多。

- 设置mask的话，setfacl -m u::rwx 中的u改为m，并且这个可不针对用户和组哦，其他的大致差不多。

- 在使用-R时，记得放在-m前面，否则不可以地

- 使用-d的话，就会把默认的都加上去，针对目录哦。

