title: IDEA开发必备插件
date: '2014-08-05 15:46:45'
updated: '2014-08-05 15:46:45'
tags: [开发工具, 插件]
permalink: /articles/2019/08/05/1564991559394.html
---
## 实用
离线下载地址： [https://plugins.jetbrains.com](https://plugins.jetbrains.com)
<br><br>

- `alibba java coding guidelines`

这是阿里巴巴代码检测插件，有了它，再也不用担心代码不规范了，因为有它一直在监视你的代码规范，为你纠正和提示！

- `FindBugs-IDEA`

检测代码中可能的bug及不规范的位置，检测的模式相比p3c更多，写完代码后检测下避免低级bug，强烈建议用一下，一不小心就发现很多老代码的bug

- `Lombok plugin`

实体类开发神器，可以简化你的实体类，让你i不再写get/set方法，还能快速的实现builder模式，以及链式调用方法，总之就是为了简化实体类而生的插件。

- `CamelCase`

将不是驼峰格式的命名自动转化驼峰；快捷键：`shift+alt+u``

- `Mybatis plugin`

可以在mapper接口中和mapper的xml文件中来回跳转，就想接口跳到实现类那样简单。

- `Rainbow Brackets`

彩虹颜色的括号，看着很舒服，能清晰的配对左右括号，敲代码效率变高

- `JRebel for IntelliJ`

一款热部署插件，只要不是修改了项目的配置文件，用它都可以实现热部署。收费的，破解比较麻烦。不过功能确实很强大。算是开发必备神器了。热部署快捷键是control+F9/command+F9。

- `.ignore`

git提交时过滤掉不需要提交的文件，很方便，有些本地文件是不需要提交到Git上的。

- `Maven Helper`

一键查看maven依赖，查看冲突的依赖，一键进行exclude依赖对于大型项目非常方便

- `MyBatisCodeHelperPro`

mybatis代码自动生成插件，大部分单表操作的代码可自动生成 减少重复劳动 大幅提升效率

## 装逼
- `CodeGlance`

在编辑区的右侧显示的代码地图，方便快速定位。 

- `Material Theme UI`

这是一款主题插件，可以让你的ide的图标变漂亮，配色搭配的很到位，还可以切换不同的颜色，甚至可以自定义颜色。默认的配色就很漂亮了，如果需要修改配色，可以在工具栏中`Tools->Material Theme`然后修改配色等。

- `Background image Plus`

这是一款可以设置idea背景图片的插件，不但可以设置固体的图片，还可以设置一段时间后随机变化背景图片，以及设置图片的透明度等等。 

- `activate-power-mode`

这是一款让你在编码的时候，整个屏幕都为之颤抖的插件。可以在工具栏`Window->activate-power-mode`进行设置。

- `Translation`

最好用的翻译插件，功能很强大，界面很漂亮

- `Nyan progress bar`

这是一个将你idea中的所有的进度条都变成萌新动画的小插件。这款插件较大，内存不是很充足的话，慎用！


## 其它
- `VisualVM Launcher`

运行java程序的时候启动visualvm，方便查看jvm的情况 比如堆内存大小的分配；某个对象占用了多大的内存，jvm调优必备工具

- `codehelper.generator`

可以让你在创建一个对象并赋值的时候，快速的生成代码，不需要一个一个属性的向里面set,根据new关键字，自动生成掉用set方法的代码，还可以一键填入默认值。

- `GenerateAllSetter`

一键调用一个对象的所有set方法并且赋予默认值 在对象字段多的时候非常方便，在做项目时，每层都有各自的实体对象需要相互转换，但是考虑BeanUtil.copyProperties()等这些工具的弊端，有些地方就需要手动的赋值时，有这个插件就会很方便，创建完对象后在变量名上面按Alt+Enter就会出来 generate all setter选项。 