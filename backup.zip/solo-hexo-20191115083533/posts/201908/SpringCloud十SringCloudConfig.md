title: SpringCloud（十）：SringCloud Config
date: '2019-08-06 15:55:55'
updated: '2019-08-06 15:58:43'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565078155409.html
---

## Quick Start
### microservice-config-server
- microservice-config-server微服务中application.xml文件的部分配置：
```
spring:
  cloud:
    config:
      server:
        git:
          uri: https://gitee.com/mmzs/microservice-spring-cloud-config-test
```
- HTTP形式访问上面配置的git资源有以下几种形式：
```
/{application}/{profile}[/{label}]
/{application}-{profile}.yml
/{label}/{application}-{profile}.yml
/{application}-{profile}.properties
/{label}/{application}-{profile}.properties
```
**例如：**<br>
![image](https://www.cnblogs.com/images/cnblogs_com/mmzs/1301081/o_spring-cloud-server00.png)

- 对于采用`http://localhost:8080/foobar/dev/master`即是第一种形式访问，不是为了得到真正的资源，它得到的结果如下图：

![image](https://www.cnblogs.com/images/cnblogs_com/mmzs/1301081/o_spring-cloud-server.png)

其中蓝色框是我们想得到的内容，但是采用这种方式不仅仅返回蓝色框的内容；其中红色框的内容代表的是资源存在的绝对路径(仅仅作为一个标识符)，而且这个看似是链接的路径是不能访问的（但这不是一个bug）。


## BootStarpApplication启动时，配置文件的加载顺序
`bootstrap.*里面的配置`--==优先于==-->`链接Config server，加载远程配置(git仓库等)`--==优先于==-->`加载application.*里面的配置`
- 建议在`bootstrap.yml`中存放一些启动后就不想修改的配置
- 如果没有设置`spring.application.name`则会默认读取`application.xml`中的信息；如果设置了，比如:`foobar`，则会寻找`foorbar-dev.xml;foobar.xml等`文件中设置的信息
