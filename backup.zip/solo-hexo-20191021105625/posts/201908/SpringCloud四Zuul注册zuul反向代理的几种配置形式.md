title: SpringCloud（四）：Zuul-注册zuul反向代理的几种配置形式
date: '2019-08-06 15:51:44'
updated: '2019-08-06 15:51:44'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565077904571.html
---

# 前提
- Eureka：服务端
- User：  客服端(microservice-provider-user)
- Zuul：  客服端(microservice-gateway-zuul)
<br>

# Embedded Zuul Reverse Proxy
# 注册zuul反向代理的几种配置形式
Zuul默认是反向代理所有注册到eureka上的微服务。<br>
 路径必须具有可以指定为ant样式模式的路径，因此/myusers/*仅匹配一个级别，
 但/myusers/**是分层匹配的。
## 第1种配置形式
- 忽略反向代理所有微服务，仅代理配置了的微服务
```
    zuul:
      ignoredServices: '*'
      routes:
        microservice-provider-user: /myusers/**
```
- 忽略反向代理指定微服务
```
    zuul:
      ignoredServices: microservice-provider-goods
      routes:
        microservice-provider-user: /myusers/**
```
## 第2种配置形式
- 反向代理microservice-provider-user微服务,路径是/myusers/**
   - aaaa这个名字任意，只要是唯一的就行
   - 为了方便测试，忽略microservice-provider-goods微服务的反向代理
    ```
        zuul:
          ignoredServices: microservice-provider-goods
          routes:
            aaaa:
              path: /myusers-path/**
              serviceId: microservice-provider-user
    ```
**注：** 示例意味着对/myusers的HTTP调用将转发到microservice-provider-user服务。<br>
## 第3种配置形式
示例意味着对/myusers-url/**的HTTP调用将通过请求microservice-provider-user服务的url地址请求microservice-provider-user服务
```
zuul:
  routes:
    abc:
      path: /myusers-url/**
      url: http://192.168.85.1:7900/
```
## 第4种配置形式
```
zuul:
  routes:
    abc:
      path: /myusers-url/**
      # 这里要用service-id而不是url
      service-id: microservice-provider-user
# 禁用掉ribbon的eureka使用
ribbon:
  eureka:
    enabled: false
# 这边是ribbon要请求的微服务的serviceId
microservice-provider-user:     
  ribbon:
    listOfServers: http://localhost:7900,http://localhost:7901
```
## 第5种配置形式
通过修改ZuulApplication.java中的代码，设置正则表达式，调用PatternServiceRouteMapper进行注入
```
@Bean
public PatternServiceRouteMapper serviceRouteMapper() {
return new PatternServiceRouteMapper("(?<name>^.+)-(?<version>v.+$)", "${version}/${name}");
}
```
==注意：== 此种方式要满足如下这种条件，microservice-provider-user服务的名字应该修改成microservice-provider-user-v1
## 第6种配置形式
- 标准配置<br>
    在application.yml为路径增加一个映射前缀
   - 全局配置
    ```
    zuul:
      prefix: /user
      # 剥掉前缀，默认是true
      strip-prefix: false
    ```
    - 局部配置：(只针对aaa这个路由)
    ```
    zuul:
      routes:
        aaa: 
          path: /myusers/**
          # 剥掉前缀，默认是true
          strip-prefix: false
    ```
    **解释：** <br>
    path后填写的是代理的服务的访问路径；
- **例如：**(以全局配置为例)<br>
此处代理的是microservice-provider-user微服务；
   - 其不配置前缀，正常的访问形式是：
        ```
        localhost:8010/microservice-provider-user/user/1
        ```
        正常的访问形式下,后台请求路径是：
        ```
        /user/1
        ```
        所以，此处的path应该填写：/user 
   - 当stripPrefix是 false时，访问路径因设置path而变成：
        ```
        localhost:8010/user/microservice-provider-user/1
        ```
        此时，后台请求路径未剥离前缀user，故请求路径是：/user/1<br>
        如果前缀设置成其它值，因为不会剥离前缀，故后台请求路径会变成/api/user/1;从而导致访问失败
   - 当stripPrefix是 true时，访问路径因设置path而变成：
        ```
        localhost:8010/user/microservice-provider-user/user/1
        ```
        此时，仅仅是在访问路径中加了一个前缀
- **适用场景：** <br>
    原来的homepage是:
    ```
    localhost:8010
    ```
    现在的homepage根据业务需求设置了classpath修改成了：
    ```
    localhost:8010/api
    ```
    那么此时就需要对application.yml进行如上配置
## 第7种配置形式
- 在application.yml修改<br>
此处的路由生效顺序是(从上到下)：先users在legacy
```
zuul:
  routes:
    users:
      path: /myusers/**
    legacy:
      path: /**
```
==**注：**== <br>
- 如果需要对代理的路由保留默认排序，则需要使用.yml文件；如果使用.properties文件，则容易造成排序不生效。
- 如果您要使用属性文件，则旧路径可能最终位于用户路径前面，从而导致用户路径无法访问。
