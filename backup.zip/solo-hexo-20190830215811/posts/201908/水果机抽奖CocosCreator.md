title: 水果机抽奖（CocosCreator）
date: '2019-08-09 22:30:48'
updated: '2019-08-09 22:45:19'
tags: [CocosCreator, 游戏开发]
permalink: /articles/2019/08/09/1565361048793.html
---
>><font color="#800080" size="6px" face="宋体">**推荐阅读：**</font>
>- <font size="4px" face="楷体"> [我的CSDN](https://blog.csdn.net/shirln)</font>
>- <font size="4px" face="楷体"> [我的博客园](https://www.cnblogs.com/shirln/)</font>
>- <font size="4px" face="楷体"> [QQ群：704621321](http://qm.qq.com/cgi-bin/qm/qr?k=HLQSQCMupMEvLxd7S061X-zpBi8Oo7pM)</font>

## 一。前言

在前面给大家分享了大转盘的抽奖方式，这是现在游戏使用较多的一种抽奖方式，今天给大家介绍另一抽奖方式——水果机，这是以前街机游戏使用较多的抽奖方式。该方式使用选中奖品的方式来进行抽奖。
## 二。算法讲解
先声明几个变量来控制选项依次选中的转动效果，可在properties里面声明，以方便调试时修改数值：

```js
//最大速度
        maxSpeed: {      
            default: 20,
            type: cc.Float,
            max: 30,
            min: 1,
        },
        //减速时间==加速时间
        duration: {      
            default: 2,
            type: cc.Float,
            max: 10,
            min: 1,
        },
        //加速度
        acc: {           
            default: 8,
            type: cc.Float,
            max: 10,
            min: 1,
        },
        gearNum: {
            default: 10,
            type: cc.Integer,
            max: 10,
            min: 1,
        },
```
不需要经常修改的变量，声明在onLoad中：

```js
this.wheelState = 0;      //转盘状态  1--加速  2--减速   0--静止
this.curSpeed = 0;        //当前速度
this.spinTime = 0;        //减速前旋转时间
this.firstAngle = 30;    //每个奖品的中间角度
this.gearAngle = 60; //每个奖品的角度
this.finalAngle = 0; //最终结果指定的角度
this.decAngle = 3 * 360;//减速旋转三周
```

抽奖转动状态设置为3个阶段，0（未转动），1（加速阶段），2（减速状态）。在加速状态时，通过判断转动速度是否达到最大速度来判断下一阶段是继续加速还是开始减速。在减速阶段,通过判断减速阶段需要转动的角度是否等于减速阶段已经转过的角度，从而判断转动是否结束。
## 三。功能实现
1.加速阶段

```js
if (self.wheelState == 1) 
{
            self.spinTime += dt;//加速阶段的时间累计
            self.uiRoot.startAward.rotation += self.curSpeed;//每帧后旋转的角度
            this.showIndexLight(self.uiRoot.startAward.rotation);//显示指针到达区域的奖品的外发光

            if (self.curSpeed <= self.maxSpeed) {
                self.curSpeed += self.acc;//修改下一帧速度
            } else {
                if (self.spinTime < self.duration) {//判断时间是否到
                    return;
                }
                //设置目标值
                self.finalAngle = self.targetID * self.gearAngle + self.firstAngle;//指针最后停留的位置
                self.maxSpeed = self.curSpeed;//当前速度未转动过程中的最大速度
                self.wheelState = 2;
            }
        }
```
2.减速阶段

```js
 else if (self.wheelState == 2) 
 {
            var curRo = self.uiRoot.startAward.rotation;
            var hadRo = curRo - self.finalAngle;//减速阶段已经转过的角度
            self.curSpeed = self.maxSpeed * ((self.decAngle - hadRo) / self.decAngle) + 0.2;//后面加一个数是使指针最后能停下来
            self.uiRoot.startAward.rotation +=  self.curSpeed;
            this.showIndexLight(self.uiRoot.startAward.rotation);

            if ((self.decAngle - hadRo) <= 0) {//判断是否转完
                self.wheelState = 0;
                self.uiRoot.startAward.rotation = self.finalAngle;
                this.showIndexLight(self.uiRoot.startAward.rotation);
                //大转盘结束后的一些列操作，根据实际情况需要增加删除
                self.ctrolWheelItem(true);
                self.uiRoot.close.active = true;
                self.uiRoot.startBtn.active = true;
                self.uiRoot.close.active = true;
                self.uiRoot.sign.interactable = true;
                self.uiRoot.wheel.interactable = true;
                for (let i = 0; i < self.uiRoot.wheelBg.childrenCount; i++) {
                    cc.find("item" + i, self.uiRoot.wheelBg).getComponent(cc.Button).interactable = true;
                }
                
                var data = cls.WheelLayer._srvData.SC_Wheel_Info;
                let info = gm.GameData.getBagDataById(data.award[this.targetID].id);
               
                self.showRewardBox(data.award[this.targetID].id, info.Icon, data.award[this.targetID].num);

                console.log("抽奖操作结束,需要同步奖励奖励数据，暂时不知道同步到哪里去");
            }
```
同步指针指到的奖品区域外发光

```js
    //显示指针到达的区域发光
    showIndexLight(rot) {
        var index = parseInt(rot / 60) % 6;/60代表每个奖品格子的角度，6代表一共6个格式
        for (let i = 0; i < this.wheelLight.length; i++) {
            this.wheelLight[i].active = false;
        }
        this.wheelLight[index].active = true;
    },
```
