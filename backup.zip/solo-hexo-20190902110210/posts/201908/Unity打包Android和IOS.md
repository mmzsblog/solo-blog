title: Unity打包——Android和IOS
date: '2019-08-30 22:01:01'
updated: '2019-08-30 22:13:14'
tags: [Unity打包, Unity打Android包, Unity打IOS包]
permalink: /articles/2019/08/30/1567173660972.html
---
### Android包
（1）首先需要安装Android SDK和Java JDK。SDK需要添加tools目录，JDK需要分别添加jdk和jre目录
（2）打开BuildSettings
![image.png](https://img.hacpai.com/file/2019/08/image-9d04f78a.png)
（3）打开PlayerSettings
![image.png](https://img.hacpai.com/file/2019/08/image-1ada1785.png)
（4）设置Android包的相关属性
![image.png](https://img.hacpai.com/file/2019/08/image-6dee069e.png)
![image.png](https://img.hacpai.com/file/2019/08/image-581aca46.png)
（5）设置好相关属性后直接Build导出APK包
![image.png](https://img.hacpai.com/file/2019/08/image-982124e8.png)
### IOS包
（1）在苹果电脑上执行打Android包的前4步，第五步时Build导出XCode工程
注意：导出的过程建议在mac上进行，否则可能会报一些奇怪的错误提示。
![image.png](https://img.hacpai.com/file/2019/08/image-34a25a7a.png)

![image.png](https://img.hacpai.com/file/2019/08/image-f763031d.png)
![image.png](https://img.hacpai.com/file/2019/08/image-6cf8cc2e.png)
![image.png](https://img.hacpai.com/file/2019/08/image-c73fcc54.png)
![image.png](https://img.hacpai.com/file/2019/08/image-e3420f2f.png)
![image.png](https://img.hacpai.com/file/2019/08/image-981e3321.png)





