title: Spring学习(二)：Spring支持的5种Bean Scope
date: '2019-08-19 16:46:41'
updated: '2019-08-19 16:46:41'
tags: [Spring]
permalink: /articles/2019/08/19/1566204401814.html
---
![](https://img.hacpai.com/bing/20180826.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 序言
Scope是定义Spring如何创建bean的实例的。Spring容器最初提供了两种bean的scope类型：singleton和prototype,但发布2.0以后，又引入了另外三种scope类型：request、session和global session,这三种只能在web 应用中才可以使用。

在创建bean的时候可以带上scope属性，scope有下面几种类型:

![1196304201902211125101701427339281.png](https://img.hacpai.com/file/2019/08/1196304201902211125101701427339281-91349e99.png)




## 概念理解
Spring官方文档表示有如下5种类型：

[2131231231.png](https://img.hacpai.com/file/2019/08/2131231231-f68fb975.png)


### singleton：
这是Spring默认的scope，表示Spring容器只创建唯一一个bean的实例，所有该对象的引用都共享这个实例，并且Spring在创建第一次后，会在Spring的IoC容器中缓存起来，之后不再创建，就是设计模式中的单例模式的形式。

并且对该bean的所有后续请求和引用都将返回该缓存中的对象实例。一般情况下，无状态的bean使用该scope。

### prototype：
代表线程每次调用或请求这个bean都会创建一个新的实例。一般情况下，有状态的bean使用该scope。
### request：
每次http请求将会有各自的bean实例，类似于prototype。
也就是说每个request作用域内的请求只创建一个实例。
### session：
在一个http session中，一个bean定义对应一个bean实例。也就是说每个session作用域内的请求只创建一个实例。
### global session：
在一个全局的http session中，一个bean定义对应一个bean实例。

但是，这个scope只在porlet的web应用程序中才有意义，它映射到porlet的global范围的session，如果普通的web应用使用了这个scope，容器会把它作为普通的session作用域的scope创建。

**注：** 再次说明spring的默认scope（bean作用域）是singleton

## 使用方式
创建bean的时候如何指定其作用域呢？
### XML方式：
```xml
< bean  id = “accountService”  class = “com.foo.DefaultAccountService”  scope = “prototype” />
```
### 注解方式：
```
@Component
@Scope("prototype")
public class User{
    …………
}
```
## 参考书籍：
Spring官网：[https://docs.spring.io/spring/docs/3.0.0.M3/reference/html/ch04s04.html](https://docs.spring.io/spring/docs/3.0.0.M3/reference/html/ch04s04.html)
