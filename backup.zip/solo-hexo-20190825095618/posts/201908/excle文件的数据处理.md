title: excle文件的数据处理
date: '2019-08-01 15:30:59'
updated: '2019-08-06 15:37:09'
tags: [数据处理]
permalink: /articles/2019/08/06/1565077029866.html
---
![](https://img.hacpai.com/bing/20190111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## excel
- 如果碰到这个问题，我首先想恭喜你运气不错！众所周知，.xls文件单个Sheet最大行数不超过65536行，最起码说明你的数据量不算很大！
- 一般处理Ecxel数据，最常用的方式是将其另存为你想要的文件格式：<br>
   单击‘文件’-->‘另存为’命令;常用的用如下几种格式：
   - 逗号分隔`.csv`格式
   - 制表符分割`.txt`格式
   - 空格分割`.prn`格式<br>
![image](https://www.cnblogs.com/images/cnblogs_com/mmzs/1301081/o_excle%e6%95%b0%e6%8d%ae%e4%bf%9d%e5%ad%98.png)

