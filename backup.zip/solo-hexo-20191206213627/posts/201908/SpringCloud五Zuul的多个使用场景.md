title: SpringCloud（五）：Zuul的多个使用场景
date: '2019-08-06 15:52:58'
updated: '2019-08-06 15:52:58'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565077978928.html
---

# Zuul Http客户端
- Zuul使用的默认HTTP客户端现在由`Apache HTTP Client`支持，而不是已经不推荐使用的`Ribbon RestClient`。
- 要使用`RestClient`或`okhttp3.0kHttpClient`，请分别设置
    ```
    ribbon.restclient.enabled = true
    //或
    ribbon.okhttp.enabled = true
    ```
如果要自定义Apache HTTP客户端或OK HTTP客户端，请提供ClosableHttpClient或OkHttpClient类型的bean。
# Cookies and Sensitive Headers
配置文件application.yml中设置
```
zuul:
  routes:
    users:
      path: /myusers/**
      sensitiveHeaders: Cookie,Set-Cookie,Authorization
      url: https://downstream
```
这里`sensitiveHeaders`是默认值，所以当你希望它不同时，才需进行设置。 这是`Spring Cloud Netflix 1.1`中的新功能（在1.0中，用户无法控制标题，并且所有Cookie都在两个方向上流动）。

`sensitiveHeaders`是黑名单，且默认不为空。 因此，要使Zuul发送所有标头（忽略的标头除外），您必须将其明确设置为空列表。 如果要将cookie或授权标头传递到后端，则必须这样做。 以下示例显示了如何使用sensitiveHeaders：
```
zuul:
  routes:
    users:
      path: /myusers/**
      sensitiveHeaders:
      url: https://downstream
```

您还可以通过设置`sensitiveHeaders`来设置`zuul.sensitiveHeaders`。 如果在路由上设置了`sensitiveHeaders`，它将覆盖全局`sensitiveHeaders`设置。
# Ignored Headers
- 常规理解：<br>
`zuul.ignoreHeaders`属性可用于丢弃一些标题。<br>
例如，设置`zuul.ignoredHeaders = Header1，Header2`;
那么Header1和Header2将不会传播到任何其他服务。<br>
默认情况下，`zuul.ignoredHeaders=`是空的。但如果`Spring Securuty`在classpath中。
它的值在是：
```
Pragma,Cache-Control,X-Frame-Options,X-Content-Type-Options,X-XSS-Protextion,Expires
```
`zuul.ignoreSecurityHeaders`的默认值为true。但是当我想要标头值的值时
从下游服务我们需要设置为false。
- 通俗来讲就是：<br>
除`route-sensitive`外，您还可以将与下游服务交互期间应丢弃的值（请求和响应）设置名为`zuul.ignoredHeaders`的全局值。 默认情况下，如果`Spring Security`不在类路径中，则它们为空。 否则，它们被初始化为一组众所周知的“安全”头文件（例如，涉及缓存），如`Spring Security`所指定的那样。 在这种情况下的假设是下游服务也可能添加这些头，但我们想从代理中获得这些值。 如果要在`Spring Security`位于类路径时不丢弃这些众所周知的`security headers`，可以将`zuul.ignoreSecurityHeaders`设置为`false`。 如果您`在Spring Security`中禁用了HTTP安全响应标头并希望下游服务提供的值，那么这样做会非常有用。
# Routes Endpoint
- 使用routes 端点的前提：<br>
   - Zuul Server需要有`Spring Boot Actuator`的依赖，否则访问/routes 端点将会返回404；
   - 设置`management.security.enabled = false`，否则将会返回401；也可添加Spring Security的依赖，这样可通过账号、密码访问routes 端点。
# Strangulation Patterns and Local Forwards
**标题：** 扼杀模式和本地转发<br>

迁移现有应用程序或API时的一种常见模式是“扼杀”旧端点，慢慢用不同的实现替换它们。 Zuul代理是一个有用的工具，因为您可以使用它来处理来自旧端点的客户端的所有流量，但将一些请求重定向到新的端点。

以下示例显示“strangle”方案的配置详细信息：
- application.yml配置示例：
```yml
zuul:
  routes:
    first:
      path: /first/**
      url: http://first.example.com
    second:
      path: /second/**
      # forward的是本地转发
      url: forward:/second
    third:
      path: /third/**
      url: forward:/3rd
    legacy:
      path: /**
      url: http://legacy.example.com
```
==**[注意]**== 忽略的模式不会被完全忽略，它们只是不由代理处理（因此它们也可以在本地有效转发）。
# Uploading Files through Zuul
**标题：** 通过zuul上传文件

- 如果使用`@EnableZuulProxy`注解，可以用代理路径上传文件，只要文件很小，它就可以正常工作。
```
curl -F "file=@d:/tmp.txt" localhost:8050/upload

curl -F "file=@d:/tmp.txt" localhost:8050/microservice-file-upload/upload
```
- 而对于大型文件，需要使用一个替代路径绕过`/zuul/*`中的Spring DispatcherServlet;
即使用`/zuul/*`的方式绕过Spring DispatcherServlet（以避免多部分处理）
    ```
    curl -F "file=@d:/tmp.txt" localhost:8050/zuul/microservice-file-upload/upload
    ```
   - application.yml配置中需要加如下语句，主要是为了避免文件过大和上传超时：
    ```yml
    # 经过zuul的请求都会使用hystrix进行包裹
    # hystrix的超时时间
    hystrix.command.default.execution.isolation.thread.timeoutInMilliseconds: 60000
    # zuul使用了ribbon做负载均衡
    ribbon:
      ConnectTimeout: 3000
      ReadTimeout: 60000
    ```
    ==**[注]**== 超时问题解决后，也可能存在堆内存太小，导致上传失败，可以堆tomcat进行如下设置： [点这里](https://www.cnblogs.com/mmzs/p/7662863.html#_label0_6)
# Disable Zuul Filters
**标题：** 禁用zuul过滤器

SpringCloud在代理和服务器模式下都默认启用了许多ZuulFilter bean。

有关可以启用的过滤器列表，请参阅[Zuul过滤器包](https://github.com/spring-cloud/spring-cloud-netflix/tree/master/spring-cloud-netflix-zuul/src/main/java/org/springframework/cloud/netflix/zuul/filters)。 

如果要禁用一个过滤器，请参照如下设置`zuul.<SimpleClassName>.<filterType>.disable=true`;按照惯例，过滤器后的包是Zuul过滤器类型。

例如，要禁用`org.springframework.cloud.netflix.zuul.filters.post.SendResponseFilter`需设置`zuul.SendResponseFilter.post.disable = true`
