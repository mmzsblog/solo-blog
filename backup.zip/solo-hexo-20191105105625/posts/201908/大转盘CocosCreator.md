title: 大转盘（CocosCreator）
date: '2019-08-09 22:45:02'
updated: '2019-08-09 22:45:02'
tags: [CocosCreator, 游戏开发]
permalink: /articles/2019/08/09/1565361901961.html
---
>><font color="#800080" size="6px" face="宋体">**推荐阅读：**</font>
>- <font size="4px" face="楷体"> [我的CSDN](https://blog.csdn.net/shirln)</font>
>- <font size="4px" face="楷体"> [我的博客园](https://www.cnblogs.com/shirln/)</font>
>- <font size="4px" face="楷体"> [QQ群：704621321](http://qm.qq.com/cgi-bin/qm/qr?k=HLQSQCMupMEvLxd7S061X-zpBi8Oo7pM)</font>

### 1.在场景中搭建大转盘场景


假设 奖项有n项，对应的每项旋转角度如下：

|第几项 | 需要旋转的角度 |
|--|--|
|0 | 360/n/2 |
|1  | 360/n+第0项角度 |
|2 | 360/n+第1项角度 |
|...  | ... |

例如：奖项一共6项
| 第几项 | 需要旋转的角度 |
|--|--|
0 | 360/n/2=30 |
|1  | 360/n+第一项角度 =30+60=90|
|2  | 90+60=150 |
|3  | 210 |
|4  | 270 |
|5  | 330 |
|...  | ... |
### 2.代码控制大转盘的转动
大转盘的思想：预先给定一个本轮大转盘的奖项的下标，然后再随机一个该奖项的角度，核心代码：

```js
var angle = app.random((idx + 1) * (-60) + 10 + 360, (idx + 0) * (-60) - 10 + 360, false) + 1800;
```
其中，60代表360/n,上面可以当成一个公式使用。
旋转函数代码：
```js
    /// 转动大转盘，idx表示奖项的下标
    rollPanel(idx, call) {
        var self = this;
        self.uiRoot.close.active = false;
        self.uiRoot.begin.enabled = false;
        var angle = app.random((idx + 1) * (-60) + 10 + 360, (idx + 0) * (-60) - 10 + 360, false) + 1800;
        var rot1 = cc.rotateTo(5, angle).easing(cc.easeExponentialInOut(10.0));
        var call1 = app.callFunc(function (adt) { self.uiRoot.close.active = true; self.uiRoot.begin.enabled = true; if (call) { call(); } });
        this.uiRoot.panel.root.stopAllActions();
        this.uiRoot.panel.root.rotation %= 360;
        this.uiRoot.panel.root.runAction(cc.sequence(rot1, call1));
    },
```