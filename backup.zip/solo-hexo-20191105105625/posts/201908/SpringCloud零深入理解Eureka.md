title: SpringCloud（零）：深入理解Eureka
date: '2019-08-06 15:48:49'
updated: '2019-08-06 15:49:20'
tags: [SpringCloud]
permalink: /articles/2019/08/06/1565077729804.html
---
# 实例和客户端的元数据
Eureka Metadata for Instances and Clients
## 0、Eureka的元数据字面理解
- **原文：** It is worth spending a bit of time understanding how the Eureka metadata works, so you can use it in a way that makes sense in your platform. There is standard metadata for information such as hostname, IP address, port numbers, the status page, and health check. These are published in the service registry and used by clients to contact the services in a straightforward way. Additional metadata can be added to the instance registration in the eureka.instance.metadataMap, and this metadata is accessible in the remote clients. In general, additional metadata does not change the behavior of the client, unless the client is made aware of the meaning of the metadata. There are a couple of special cases, described later in this document, where Spring Cloud already assigns meaning to the metadata map.
- **译文：** 花时间了解Eureka元数据的工作方式是一件值得的事，这样您就可以在您的平台上使用它了。标准元数据的信息包括：例如主机名、IP地址、端口号、状态页和健康检查。这些服务发布在服务注册中心，并由客户端使用以简单的方式与服务联系。可以将其他元数据添加到==eureka.instance.metadataMap==中的实例注册中，并且远程客户端可以访问该元数据。通常，附加的元数据不会改变客户端的行为，除非使客户端知道元数据的含义。本文后面将描述几个特殊情况，其中Spring Cloud已经为元数据映射分配了含义。
## 1、配置Eureka的元数据
```
eureka:
  instance:
    metadata-map: 
      zone: ABC  # eureka可以理解的元数据，因为eureka中有这个zone的名字
      mmzs: BBC  # 不会影响客户端行为，因为eureka中没有mmzs这个名字，eureka不能理解这个元数据
```      
# Using the EurekaClient
不要在@PostConstruct方法或@Scheduled方法中使用EurekaClient（或任何可能尚未启动ApplicationContext的地方）。
# 为什么注册服务这么慢？
官网文档：http://cloud.spring.io/spring-cloud-static/Finchley.SR1/single/spring-cloud.html#_why_is_it_so_slow_to_register_a_service   
<br>作为一个实例，还会涉及到一个默认的持续时间为30秒的注册表（通过客户端的Service URL）的周期性心跳。
直到实例、服务端和客户端在本地缓存中都具有相同的元数据（因此它可能会花费3个心跳周期），客户端才可发现服务。您可以通过设置==eureka.instance.leaseRenewalIntervalInSeconds==来改变周期时间；将其设置为小于30秒，加快客户端连接到其他服务端的过程。==在生产中，最好是坚持使用默认，因为在服务器内部有一些计算，它们会对租赁续订期做出一些假设。==
# eureka服务实例的应用名称是？
优先级：2>0>1<br>
0、默认是读取配置
```
spring:
  application:
    # 建议大家都是用小写
    name: microservice-provider-user
```
1、如该配置没有，那么就是unknown<br>
2、还可以通过下面的配置：
```
# 这种配置和swagger没有冲突，而第0种配置可能会有冲突
eureka
  instance
    appname: USER-SERVICE-MMZS
```
# Eureka开启自我保护的提示
当出现以下语句时：<br>
<font color="red">EMERGENCY! EUREKA MAY BE INCORRECTLY CLAIMING INSTANCES ARE UP WHEN THEY'RE NOT. RENEWALS ARE LESSER THAN THRESHOLD AND HENCE THE INSTANCES ARE NOT BEING EXPIRED JUST TO BE SAFE. </font>
表明Eureka已经开启自我保护。
# 如何解决Eureka Server不踢出已关停的节点的问题？
- **server端:**
```
# 设为false，关闭自我保护主要
eureka.server.enable-self-preservation
# 清理间隔（单位毫秒，默认是60*1000）
eureka.server.eviction-interval-timer-in-ms     
```
- **client端：**
```
# 开启健康检查（需要spring-boot-starter-actuator依赖）
eureka.client.healthcheck.enabled = true
# 租期更新时间间隔（默认30秒）
eureka.instance.lease-renewal-interval-in-seconds =10
# 租期到期时间（默认90秒）
eureka.instance.lease-expiration-duration-in-seconds =30  
```
- **示例：**
1. **服务器端配置：**
```
    eureka:
        server:
            enableSelfPreservation: false
            evictionIntervalTimerInMs: 4000
```
2. **客户端配置：**
```
    eureka:
        instance:
          leaseRenewalIntervalInSeconds: 10
          leaseExpirationDurationInSeconds: 30
```
==**注：**== 在生产中，更改Eureka更新频率将打破服务器的自我保护功能，所以最好坚持使用默认值，因为在服务器内部有一些计算，他们对续约做出假设。<br>
参考文档：https://github.com/spring-cloud/spring-cloud-netflix/issues/373
# Eureka配置instanceId显示IP
- 直接配置：
```
eureka:
  client:
    serviceUrl:
      defaultZone: http://localhost:8761/eureka/
  instance:
    prefer-ip-address: true
    instance-id: ${spring.cloud.client.ip-address}:${server.port}
```
**==注==：** 如果只是配置了eureka.instance.prefer-ip-address=true，而不配置eureka.instance.instance-id，那还是显示localhost，但ip地址是可以访问得了。
- 手工指定IP(推荐)
<br>添加以下配置：
```
# 指定此实例的ip
eureka.instance.ip-address = 127.0.0.1
# 注册时使用ip而不是主机名
eureka.instance.prefer-ip-address = true
```
- Spring Cloud Netflix Eureka: 多网卡环境下Eureka服务注册IP选择问题<br>
链接：https://blog.csdn.net/neosmith/article/details/53126924
# Eureka Environment和Eureka DataCenter的配置：
1. Eureka Environment的配置：
```
    eureka.environment: 字符串
```
参考文档：
https://github.com/Netflix/eureka/wiki/Configuring-Eureka
2. Eureka DataCenter的配置
```
    eureka.datacenter: cloud
```
参考文档：https://github.com/Netflix/eureka/wiki/Configuring-Eureka   
<br>这边说：配置-Deureka.datacenter=cloud，这样eureka将会知道是在AWS云上
3. 示例：
```
    eureka: 
      datacenter: cloud
      environment: product
```
# Eureka配置最佳实践总结
参考文档：
https://github.com/spring-cloud/spring-cloud-netflix/issues/203
