title: Unity之SDK接入（Unity与Android通信）
date: '2019-09-11 22:13:43'
updated: '2019-09-14 09:54:11'
tags: [游戏开发, Unity]
permalink: /articles/2019/09/11/1568211223627.html
---
# 序言
## 首先介绍一点关于Android与unity通信的知识：

完成通信主要靠unity中的class.jar包（在unity的安装目录下）。

### 在unity中调用android的方法：

jo.call("方法名"[,参数名])   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;其中[]代表可有可无。

### 在android中调用unityu的方法：

导入class.jar包，继承UnityPlayerActivity，使用UnityPlayer.UnitySendMessage("游戏对象名"，"unity中的方法名","参数")

## 正文
现在，我们已经有基础了，可以动手操作了

### 1.eclipse中新建Android工程
导入Unity安装目录下的class.jar类,
并添加MainActivity.java代码：
```
package com.example.test;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

import android.os.Bundle;

public class MainActivity extends UnityPlayerActivity  {
    
    protected void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
    } 
    public void Send() {
        UnityPlayer.UnitySendMessage("aaa", "AndroidCallBack", "okokoko");
    }
}
```
![image.png](https://img.hacpai.com/file/2019/09/image-8149e6f8.png)
从eclipse中导出jar包
![image.png](https://img.hacpai.com/file/2019/09/image-5d55cc77.png)
![image.png](https://img.hacpai.com/file/2019/09/image-a9293897.png)
![image.png](https://img.hacpai.com/file/2019/09/image-469e8eb4.png)
### 2.Unity中，新建工程，
![image.png](https://img.hacpai.com/file/2019/09/image-a2db0521.png)
编写EclipseCall.cs代码如下：
```
using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class EclipseCall : MonoBehaviour
{
    private AndroidJavaClass jc;
    private AndroidJavaObject jo;
    private Text text;
    private Button btn;


    //单例模式
    private static EclipseCall _instance;
    public static EclipseCall Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new EclipseCall();
            }
            return _instance;
        }
    }

    void Start()
    {
        text = GameObject.Find("aaa").GetComponent<Text>();
        btn = GameObject.Find("Button").GetComponent<Button>();
        this.name = "aaa";
        
        _instance = this;
        jc = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        jo = jc.GetStatic<AndroidJavaObject>("currentActivity");
    }

    public void ClickBtn()
    {
        jo.Call("Send");
    }

    public void AndroidCallBack(String str)
    {
        text.text = str;
    }
}
```
![image.png](https://img.hacpai.com/file/2019/09/image-0d591407.png)
将eclipse中导出的jar包拖进libs文件中
![image.png](https://img.hacpai.com/file/2019/09/image-9eb5e36c.png)
打包：
![image.png](https://img.hacpai.com/file/2019/09/image-6688efa2.png)
## 下面给大家捋一下思路：

从下图中可以看出，在Unity中通过按钮点击事件调用eclipse中的Send方法，eclipse中Send方法又调用了unity的AndroidCallBack方法，通过eclipse传递参数到unity中，实现将参数显示在Text游戏对象身上。
![image.png](https://img.hacpai.com/file/2019/09/image-6f783c3a.png)
UI：
![image.png](https://img.hacpai.com/file/2019/09/image-0bf36475.png)
## 最后，给大家总结几点注意事项：

- 1.记得点击eclipse菜单栏的Project——>Properties——>Java Build Path_》Add External JARs...——>选择Unity安装目录下的class.jar——>Apply——>Apply and Cliose

- 2.**Activity.java必须继承Unity，且要实现Android与Unity的通信，必须保证一个Android项目只有一个**Activity.java类

- 3.unity与anddroid通信，必须从unity端打包，即上述方式。

- 4.调用Unity的函数时记得参数的选择，注意函数名，游戏对象。

- 5.脚本的绑定：unity中注意上面第4的游戏对象，必须绑定有调用的函数名的脚本。

- 6.unity打包的包名必须和eclipse中的对应，打包时记得添加场景。

- 7.如果在实际开发中（接SDK），打包是还必须注意填写keystore,密码。具体方法参考http://www.cnblogs.com/shirln/p/8384438.html


















































